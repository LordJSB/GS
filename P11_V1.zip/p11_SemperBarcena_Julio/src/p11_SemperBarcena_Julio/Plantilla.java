package p11_SemperBarcena_Julio;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author julio.semper
 *
 * 
 */
public class Plantilla {
	ArrayList<Empleado> plantilla = new ArrayList<>();

	/**
	 * Constructor predeterminado para la totalidad de empleados de la empresa
	 * 
	 * @throws FileNotFoundException
	 * 
	 */
	public Plantilla() throws FileNotFoundException {
		plantilla = setPlantilla();
	}

	/**
	 * Función encargada de devolver la plantilla de trabajadores actuales
	 * 
	 * @return plantilla lista de empleados establecidos por el usuario en
	 *         {@link Plantilla#setPlantilla()}
	 * 
	 */
	public ArrayList<Empleado> getPlantilla() {
		return plantilla;
	}

	/**
	 *
	 * Lee un archivo .txt con los datos del empleado separado por comas, pasándolo
	 * a un formato de lista de Strings. El método acepta dos tipos de datos:
	 * <ul>
	 * <li>Si se indican sólo nombre, apellidos y sueldo bruto, se aplicarán los
	 * estándares del objeto {@link Empleado#Empleado(String, String, int)}</li>
	 * <li>En caso contrario, después del sueldo bruto se especificarán los anios de
	 * antiguedad, número de hijos y tipo de puesto</li>
	 * </ul>
	 *
	 * @return Lista de objetos Empleado creados a partir del archivo leído
	 * @throws FileNotFoundException Si no se encuentra el archivo dado
	 */
	public ArrayList<Empleado> setPlantilla() throws FileNotFoundException {
		ArrayList<Empleado> plantilla = new ArrayList<>();
		Scanner lectura = new Scanner(System.in);
		System.out.print(
				"Por favor, inserte la ruta donde se encuentra el archivo '.txt' donde se ubican los datos de entrada.\nRecuerde que se puede obtener la ruta del archivo pulsando click en la barra de dirección del explorador de archivos de Windows: ");
		String input = lectura.next();
		File entrada = new File(input);
		Scanner sc = new Scanner(entrada);
		while (sc.hasNextLine()) {
			String cabezal = sc.nextLine();
			String[] parte = cabezal.split(",");
			if (parte.length != 3 && parte.length != 6) {
				System.err.println("Error: formato de archivo inválido en: " + cabezal);
				continue;
			}
			String nombre = parte[0];
			String apellidos = parte[1];
			int sueldoBruto = Integer.parseInt(parte[2]);
			if (parte.length == 3) {
				plantilla.add(new Empleado(nombre, apellidos, sueldoBruto));
			} else {
				int antiguedad = Integer.parseInt(parte[3]);
				int hijos = Integer.parseInt(parte[4]);
				String categoria = parte[5].toLowerCase();
				plantilla.add(new Empleado(nombre, apellidos, sueldoBruto, antiguedad, hijos, categoria));
			}
		}
		sc.close();
		lectura.close();
		return plantilla;
	}

	/**
	 * Función encargada de comprobar que el contenido transmitido por teclado es un
	 * numero. Usado en {@link Plantilla#setPlantilla()}
	 * 
	 * @param sc   función Scanner que lee el nuevo input del usuario,
	 *             preferiblemente un número
	 * @param algo cadena que contiene un mensaje con instrucciones para el usuario
	 *             en búsqueda de un número
	 * @return x numero final
	 * 
	 */
	@SuppressWarnings("resource")
	public int compruebaNumeros(Scanner sc, String algo) {
		int x = 0;
		boolean seguir = false;
		do {
			sc = new Scanner(System.in);
			System.out.print(algo);
			if (sc.hasNextInt()) {
				x = sc.nextInt();
				seguir = true;
			} else {
				System.out.println("ERROR: introduce un entero");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}

	/**
	 * Función encargada de comprobar que el contenido transmitido por teclado es
	 * una categoria de empleado. Usado en {@link Plantilla#setPlantilla()}
	 * 
	 * @param sc   función Scanner que lee el nuevo input del usuario,
	 *             preferiblemente una de las 4 categorías disponibles
	 * @param algo cadena que contiene un mensaje con instrucciones para el usuario
	 *             en búsqueda de una categoría válida
	 * @return x categoria de empleado valida
	 * 
	 */
	@SuppressWarnings("resource")
	public String compruebaCategoria(Scanner sc, String algo) {
		String x = "";
		boolean seguir = false;
		do {
			sc = new Scanner(System.in).useDelimiter("\r\n");
			System.out.print(algo);
			String aux = sc.next();
			if (aux.equalsIgnoreCase("junior") || aux.equalsIgnoreCase("senior") || aux.equalsIgnoreCase("manager")
					|| aux.equalsIgnoreCase("arquitecto")) {
				x = aux;
				seguir = true;
			} else {
				System.out.println(
						"ERROR: En AENA, sólo existen las siguientes categorías: 'Junior', 'Senior', 'Manager' y 'Arquitecto'");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}
}
