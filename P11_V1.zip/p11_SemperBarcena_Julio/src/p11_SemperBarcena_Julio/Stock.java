package p11_SemperBarcena_Julio;

import java.util.ArrayList;

/**
 * @author julio.semper
 *
 */
public class Stock {
	ArrayList<Material> almacen = new ArrayList<>();

	/**
	 * Constructor predeterminado para el almacén de la empresa. Este almacén, si
	 * bien esta abierto a futuros cambios, actualmente empleara valores
	 * predeterminados establecidos por su funcion Set
	 * 
	 */
	public Stock() {
		almacen = setAlmacen();
	}

	/**
	 * Función encargada de devolver el contenido actual del almacen de la empresa
	 * 
	 * @return almacen Lista de objetos Material que contiene la totalidad de stock
	 *         disponible
	 * 
	 */
	public ArrayList<Material> getAlmacen() {
		return almacen;
	}

	/**
	 * Función encargada de asignar el contenido del stock disponible de la empresa
	 * 
	 * @return almacen Lista de materiales disponibles para los empleados
	 * 
	 */
	public ArrayList<Material> setAlmacen() {
		ArrayList<Material> almacen = new ArrayList<>();
		almacen.addAll(stockPortatilesEmpresa());
		almacen.addAll(stockTelefonosEmpresa());
		almacen.addAll(stockCochesEmpresa());
		return almacen;
	}

	/**
	 * Función que establece los portatiles disponibles en el almacen. Esta función
	 * es vital para la correcta creación del {@link Stock#setAlmacen()}
	 * 
	 * @return portatiles lista de objetos Material de todos los portatiles que
	 *         habra en el almacen
	 * 
	 */
	public ArrayList<Material> stockPortatilesEmpresa() {
		ArrayList<Material> portatiles = new ArrayList<>();
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 5; j++) {
				portatiles.add(new Material("portatil", i));
			}
		}
		return portatiles;
	}

	/**
	 * Función que establece los telefonos disponibles en el almacen. Esta función
	 * es vital para la correcta creación del {@link Stock#setAlmacen()}
	 * 
	 * @return telefonos lista de objetos Material de todos los coches que habra en
	 *         el almacen
	 * 
	 */
	public ArrayList<Material> stockTelefonosEmpresa() {
		ArrayList<Material> telefonos = new ArrayList<>();
		for (int i = 1; i <= 2; i++) {
			for (int j = 1; j <= 5; j++) {
				telefonos.add(new Material("telefono", i));
			}
		}
		return telefonos;
	}

	/**
	 * Función que establece los coches disponibles en el almacen. Esta función es
	 * vital para la correcta creación del {@link Stock#setAlmacen()}
	 * 
	 * @return coches lista de objetos Material de todos los coches que se podran
	 *         alquilar para los empleados
	 * 
	 */
	public ArrayList<Material> stockCochesEmpresa() {
		ArrayList<Material> coches = new ArrayList<>();
		for (int i = 1; i <= 2; i++) {
			for (int j = 1; j <= 5; j++) {
				coches.add(new Material("coche", i));
			}
		}
		return coches;
	}

}
