package p11_SemperBarcena_Julio;

import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;

/**
 * @author julio.semper
 *
 */
public class Main {

	/**
	 * Función principal del programa
	 * 
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		Stock almacen = new Stock();
		ArrayList<String> salida = new ArrayList<>(); // AQUI GUARDAMOS EL RESULTADO A IMPRIMIR
		System.out.println("Bienvenido al departamento comercial de AENA [sin h :) ] ");
		Plantilla empleadosAena = new Plantilla();
		empleadosAena = compruebaStock(almacen, empleadosAena);
		cuentaEmpleados(empleadosAena, salida);
		calculaMediaHijos(empleadosAena, salida);
		empleadoMasAsalariado(empleadosAena, salida);
		sueldoNetoMedio(empleadosAena, salida);
		listadoCoches(empleadosAena, salida);
		calculaCostesEmpresa(empleadosAena, salida);
		escribeFichero(salida);
		System.out.println(
				"¡Hecho! El documento final se ha guardado en 'E:\\GS\\PRGRM\\Eclipse-Workspace\\p12_SemperBarcena_Julio'");
	}

	/**
	 * Función encargada del recuento de empleados según su categoria
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()} por el usuario
	 * @param salida		 Lista de Strings que contendrá el recuento de empleados
	 */
	public static void cuentaEmpleados(Plantilla empleadosAena, ArrayList<String> salida) {
		int cJ = 0, // Contador que registra el número de juniors de la empresa
				cS = 0, // Contador que registra el número de seniors de la empresa
				cM = 0, // Contador que registra el número de managers de la empresa
				cA = 0; // Contador que registra el número de arquitectos de la empresa
		for (Empleado e : empleadosAena.getPlantilla()) {
			switch (e.getCategoria().toLowerCase()) {
			case "junior":
				cJ++;
				break;
			case "senior":
				cS++;
				break;
			case "manager":
				cM++;
				break;
			case "arquitecto":
				cA++;
				break;
			}
		}
		salida.add("De entre toda la plantilla, se listarán según su categoría: ");
		salida.add("Número de trabajadores Juniors: " + cJ);
		salida.add("Número de trabajadores Seniors: " + cS);
		salida.add("Número de trabajadores Managers: " + cM);
		salida.add("Número de trabajadores Arquitectos: " + cA);
	}

	/**
	 * Función encargada de calcular la media de hijos de toda la plantilla
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()} por el usuario
	 * @param salida 		Lista de Strings que contendrá el recuento de empleados
	 */
	public static void calculaMediaHijos(Plantilla empleadosAena, ArrayList<String> salida) {
		float media = 0;
		int total = 0, hijos = 0;
		for (Empleado e : empleadosAena.getPlantilla()) {
			hijos += e.getHijos();
			if (e.getHijos() != 0) {
				total++;
			}
		}
		if (total == 0) {
			System.out.println("");
		} else {
			media = hijos / total;
		}
		salida.add("El total de hijos de la empresa es de " + hijos + " hijos, ajustándose a unos " + Math.floor(media)
				+ " hijos por empleado");
	}

	/**
	 * Función encargada de encontrar el sueldo neto más alto de toda la plantilla
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()} por el usuario
	 * 
	 */
	public static void empleadoMasAsalariado(Plantilla empleadosAena, ArrayList<String> salida) {
		int maxSueldoNeto = 0, maxSueldoBruto = 0;
		String nombreMaxNeto = "", nombreMaxBruto = "";
		for (Empleado e : empleadosAena.getPlantilla()) {
			if (e.getSueldoNeto() > maxSueldoNeto) {
				maxSueldoNeto = e.getSueldoNeto();
				nombreMaxNeto = e.getNombre() + " " + e.getApellidos();
			}
			if (e.getSueldoBruto() > maxSueldoBruto) {
				maxSueldoBruto = e.getSueldoBruto();
				nombreMaxBruto = e.getNombre() + " " + e.getApellidos();
			}
		}
		salida.add("El sueldo neto más alto de toda la plantilla pertenece a " + nombreMaxNeto + " con un sueldo de "
				+ maxSueldoNeto + "\u20AC anuales");
		salida.add("El sueldo bruto más alto de toda la plantilla pertenece a " + nombreMaxBruto + " con un sueldo de "
				+ maxSueldoBruto + "\u20AC anuales");
	}

	/**
	 * Función encargada de calcular la media de sueldo neto de la empresa
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()}
	 * 
	 */
	public static void sueldoNetoMedio(Plantilla empleadosAena, ArrayList<String> salida) {
		DecimalFormat df = new DecimalFormat("####.##");
		double media = 0;
		int total = 0, sueldo = 0;
		for (Empleado e : empleadosAena.getPlantilla()) {
			sueldo += e.getSueldoNeto();
			total++;
		}
		media = sueldo / total;
		salida.add("La media de los sueldos netos de toda la plantilla es de " + df.format(media) + "\u20AC anuales");
	}

	/**
	 * Función encargada de listar los propietarios de los coches de la empresa
	 * 
	 * @param empleadosAena Version alterada de la plantilla teniendo en cuenta el
	 *                      stock disponible por parte de la empresa
	 *                      {@link #compruebaStock(Stock, Plantilla)}
	 * 
	 */
	public static void listadoCoches(Plantilla empleadosAena, ArrayList<String> salida) {
		int totalCoches = 0;
		for (Empleado empleado : empleadosAena.plantilla) {
			int cochesC1 = 0, cochesC2 = 0;
			if (empleado.tieneCocheCat() == 1) {
				cochesC1++;
				totalCoches++;
			} else if (empleado.tieneCocheCat() == 2) {
				cochesC2++;
				totalCoches++;
			}
			if (cochesC1 != 0) {
				salida.add(empleado.getNombre() + " " + empleado.getApellidos() + " tiene " + cochesC1
						+ " coche de empresa de categoría 1.");
			} else if (cochesC2 != 0) {
				salida.add(empleado.getNombre() + " " + empleado.getApellidos() + " tiene " + cochesC2
						+ " coche de empresa a todo riesgo de categoría 2.");
			} else if (!(empleado.getCategoria().equalsIgnoreCase("manager"))
					|| !(empleado.getCategoria().equalsIgnoreCase("arquitecto"))) {
				salida.add(empleado.getNombre() + " " + empleado.getApellidos()
						+ " no posee un coche de empresa debido a que carece del puesto requerido para ello.");
			} else {
				salida.add(empleado.getNombre() + " " + empleado.getApellidos()
						+ " no posee un coche de empresa debido a una falta de ellos en el concesionario.");
			}
		}
		if (totalCoches == 1) {
			salida.add("En total hay " + totalCoches + " coche en la plantilla");
		} else {
			salida.add("En total hay " + totalCoches + " coches en la plantilla");
		}

	}

	/**
	 * Función encargada de calcular la inversion de capital de la empresa por medio
	 * de sus empleados y los materiales que disponen
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()}
	 * 
	 */
	public static void calculaCostesEmpresa(Plantilla empleadosAena, ArrayList<String> salida) {
		int costesMaterial = 0, costeSueldo = 0;
		for (Empleado e : empleadosAena.plantilla) {
			for (Material m : e.getEquipamiento()) {
				costesMaterial += m.getCoste();
			}
			costeSueldo += e.getSueldoBruto();
		}
		salida.add("La empresa ha invertido " + costeSueldo
				+ "\u20AC anuales en sueldos a sus empleados, mientras que invirtió " + costesMaterial
				+ "\u20AC anuales en materiales a sus empleados, dando un gasto total de "
				+ (costesMaterial + costeSueldo) + "\u20AC anuales");
	}

	/**
	 * Función encargada de comprobar la existencia de stock disponible para los
	 * empleados. En caso contrario, no se les asignará equipamiento
	 * 
	 * @param empleadosAena Version alterada de la plantilla teniendo en cuenta el
	 *                      stock disponible por parte de la empresa
	 *                      {@link #compruebaStock(Stock, Plantilla)}
	 * 
	 */
	public static Plantilla compruebaStock(Stock almacen, Plantilla empleadosAena) {
		Plantilla empleadosConMateriales = empleadosAena;
		for (Empleado e : empleadosAena.getPlantilla()) {
			for (Material ea : e.getEquipamiento()) {
				boolean asignado = false;
				for (Material a : almacen.getAlmacen()) {
					if (ea.getNombre().equalsIgnoreCase(a.getNombre()) && !(a.getEnUso() || ea.getEnUso())) {
						a.setEnUso(true);
						ea.setEnUso(true);
						asignado = true;
					}
				}
				if (!asignado) {
					e.vaciaMaterial(e, ea);
				}
			}
		}
		return empleadosConMateriales;
	}

	/**
	 * Este método recoge todos los resultados obtenidos del resto de métodos, los
	 * establece en un fichero .txt y lo crea dentro del 'Workspace' actual
	 *
	 * @param salida lista de Strings con el resultado completo final
	 */
	private static void escribeFichero(ArrayList<String> salida) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("resultado.txt"));

			for (String l : salida) {
				bw.write(l + "\n");
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
