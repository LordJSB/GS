package practica7_POO1;

import java.util.ArrayList;

public class Herramienta {

	private String tipoHerramienta = "Herramienta de Ejemplo";
	private ArrayList<String> nombresValidos = new ArrayList<>();
	private boolean enUso;
	private String tareaEnUso;

	public Herramienta(String tipoHerramienta) { // Constructor de herramientas
		this.listaAutorizada();
		setTipoHerramienta(tipoHerramienta);
		setEnUso(false);
		setTareaEnUso("LIBRE");
	}

	public Herramienta() { // Constructor vacio. Uso de métodos facil
		this.listaAutorizada();
	}

	public String getTipoHerramienta() {
		return tipoHerramienta;
	}

	public void setTipoHerramienta(String tipoHerramienta) { // Aquí se comprueba si una herramienta es válida o no
		if (this.nombresValidos.indexOf(tipoHerramienta) >= 0) {
			this.tipoHerramienta = tipoHerramienta;
		} else {
			System.out.println("ERROR. Esta herramienta no es válida: " + tipoHerramienta);
			this.tipoHerramienta = "ERROR";
		}
	}

	public boolean isEnUso() {
		return enUso;
	}

	public void setEnUso(boolean enUso) {
		this.enUso = enUso;
	}

	public String getTareaEnUso() {
		return tareaEnUso;
	}

	public void setTareaEnUso(String tareaEnUso) {
		this.tareaEnUso = tareaEnUso;
	}

	private void listaAutorizada() { // lista de herramientas válidas para el mantenimiento
		nombresValidos.add("Carraca");
		nombresValidos.add("Alicate");
		nombresValidos.add("Destornillador");
		nombresValidos.add("Berbiquí");
		nombresValidos.add("Espejos");
		nombresValidos.add("Galgas de medición");
		nombresValidos.add("Martillo");
		nombresValidos.add("Trenzador");
	}

	public String getListaAutorizada() { // Expone todo el contenido de las herramientas válida en un formato concreto
											// para futuras impresiones
		String res = "\n";
		for (String x : this.nombresValidos) {
			res += "\t" + x + "\n";
		}
		return res;
	}
}
