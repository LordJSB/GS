package practica7_POO1;

import java.util.ArrayList;

public class Mantenimiento {

	private String nombre;
	private ArrayList<Pieza> piezas = new ArrayList<>();
	private ArrayList<Herramienta> herramientas = new ArrayList<>();
	private int horasOficial;
	private int horasOperario;

	public Mantenimiento(String nombre, ArrayList<Pieza> piezas, ArrayList<Herramienta> herramientas, int horasOficial,
			int horasOperario) {
		this.nombre = nombre;
		this.piezas = piezas;
		this.herramientas = herramientas;
		this.horasOficial = horasOficial;
		this.horasOperario = horasOperario;
	}

	public String getNombre() {return nombre;}
	public void setNombre(String nombre) {this.nombre = nombre;}

	public ArrayList<Pieza> getPiezas() {return piezas;}
	public void setPiezas(ArrayList<Pieza> piezas) {this.piezas = piezas;}

	public ArrayList<Herramienta> getHerramientas() {return herramientas;}
	public void setHerramientas(ArrayList<Herramienta> herramientas) {this.herramientas = herramientas;}

	public int getHorasOficial() {return horasOficial;}
	public void setHorasOficial(int horasOficial) {this.horasOficial = horasOficial;}

	public int getHorasOperario() {return horasOperario;}
	public void setHorasOperario(int horasOperario) {this.horasOperario = horasOperario;}

}