package practica7_POO1;

import java.util.ArrayList;

public class PartesAvion {

	private String parte;
	private ArrayList<Mantenimiento> tarea = new ArrayList<>();

	public PartesAvion(String parte, ArrayList<Mantenimiento> tarea) {
		this.parte = parte;
		this.tarea = tarea;
	}

	public String getParte() {return parte;}
	public void setParte(String parte) {this.parte = parte;}

	public ArrayList<Mantenimiento> getTarea() {return tarea;}
	public void setTarea(ArrayList<Mantenimiento> tarea) {this.tarea = tarea;}
	
}
