package practica7_POO1;

import java.util.ArrayList;

public class Pieza {

	private String tipoPieza = "Pieza de Ejemplo";
	private ArrayList<String> nombresValidos = new ArrayList<>();
	private int cantidadAceite;
	private boolean enUso;
	private String tareaEnUso;
	
	public Pieza(String tipoPieza) { // Constructor empleado para la creación de objetos Avion
		this.listaAutorizada();
		setTipoPieza(tipoPieza);
		setEnUso(false);
		setTareaEnUso("LIBRE");
	}
	
	public Pieza(String tipoPieza, int cantidadAceite) { // Constructor empleado para la creación de aceite
		this.listaAutorizada();
		setTipoPieza(tipoPieza);
		this.cantidadAceite=cantidadAceite;
	}

	public Pieza() { // Constructor vacio. Para acceder a metodos
		this.listaAutorizada();
	}

	public String getTipoPieza() {
		return tipoPieza;
	}

	public void setTipoPieza(String tipoPieza) { // Aquí se comprueba si una pieza es válida o no
		if (this.nombresValidos.indexOf(tipoPieza) >= 0) {
			this.tipoPieza = tipoPieza;
		} else {
			System.out.println("ERROR. Esta herramienta no es válida: " + tipoPieza);
			this.tipoPieza = "ERROR";
		}
	}

	public int getCantidadAceite() {
		return cantidadAceite;
	}

	public void setCantidadAceite(int cantidadAceite) {
		this.cantidadAceite = cantidadAceite;
	}
	
	public boolean isEnUso() {
		return enUso;
	}

	public void setEnUso(boolean enUso) {
		this.enUso = enUso;
	}
	
	public String getTareaEnUso() {
		return tareaEnUso;
	}

	public void setTareaEnUso(String tareaEnUso) {
		this.tareaEnUso = tareaEnUso;
	}
	
	private void listaAutorizada() { // lista de piezas válidas para el mantenimiento
		nombresValidos.add("Aceite");
		nombresValidos.add("Tornillo sujeción");
		nombresValidos.add("Tuerca sujeción");
		nombresValidos.add("Pistón");
		nombresValidos.add("Panel superior");
		nombresValidos.add("Pieza sujeción");
	}

	public String getListaAutorizada() { // Expone todo el contenido de las piezas válida en un formato concreto para futuras impresiones
		String res = "\n";
		for (String x : this.nombresValidos) {
			res += "\t" + x + "\n";
		}
		return res;
	}

}
