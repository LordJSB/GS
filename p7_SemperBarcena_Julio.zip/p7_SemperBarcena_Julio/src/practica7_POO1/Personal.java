package practica7_POO1;

public class Personal {

	private String nombre;
	private String apellidos;
	private boolean oficial;
	private int horas;
	private boolean ocupado;

	public Personal(String nombre, String apellidos, boolean oficial, int horas) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.oficial = oficial;
		this.horas = horas;
		setOcupado(false);
	}
	
	public Personal(String nombre, String apellidos, boolean oficial) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.oficial = oficial;
		horas = 8;
		setOcupado(false);
	}

	public String getNombre() {return nombre;}
	public void setNombre(String nombre) {this.nombre = nombre;}

	public String getApellidos() {return apellidos;}
	public void setApellidos(String apellidos) {this.apellidos = apellidos;}

	public boolean getCargoEmpresa() {return oficial;} //Si no es oficial es operario
	public void setCargoEmpresa(boolean cargoEmpresa) {this.oficial = cargoEmpresa;}

	public int getHoras() {return horas;}
	public void setHoras(int horas) {this.horas = horas;}

	public boolean isOcupado() {return ocupado;}
	public void setOcupado(boolean ocupado) {this.ocupado = ocupado;}
}
