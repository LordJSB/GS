package practica7_POO1;

import java.util.ArrayList;

public class Avion {

	private String matricula;
	private PartesAvion alerones;
	private PartesAvion flaps;
	private PartesAvion spoilers;
	private PartesAvion frenosAerodinamicos;
	private PartesAvion slats;

	public Avion(String matricula) {
		this.matricula = matricula;
		this.alerones = Avion.defineAlerones();
		this.flaps = Avion.defineFlaps();
		this.spoilers = Avion.defineSpoilers();
		this.frenosAerodinamicos = Avion.defineFrenos();
		this.slats = Avion.defineSlats();
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public PartesAvion getAlerones() {
		return alerones;
	}

	public void setAlerones(PartesAvion alerones) {
		this.alerones = alerones;
	}

	public PartesAvion getFlaps() {
		return flaps;
	}

	public void setFlaps(PartesAvion flaps) {
		this.flaps = flaps;
	}

	public PartesAvion getSpoilers() {
		return spoilers;
	}

	public void setSpoilers(PartesAvion spoilers) {
		this.spoilers = spoilers;
	}

	public PartesAvion getFrenosAerodinamicos() {
		return frenosAerodinamicos;
	}

	public void setFrenosAerodinamicos(PartesAvion frenosAerodinamicos) {
		this.frenosAerodinamicos = frenosAerodinamicos;
	}

	public PartesAvion getSlats() {
		return slats;
	}

	public void setSlats(PartesAvion slats) {
		this.slats = slats;
	}

	private static PartesAvion defineAlerones() {
		ArrayList<Pieza> auxp = new ArrayList<>();
		ArrayList<Herramienta> auxh = new ArrayList<>();
		ArrayList<Mantenimiento> res = new ArrayList<>();

		auxp.add(new Pieza("Aceite", 150));
		auxh.add(new Herramienta("Alicate"));
		auxh.add(new Herramienta("Carraca"));
		Mantenimiento aux = new Mantenimiento("Engrasado de alerones", auxp, auxh, 2, 4);
		res.add(aux);

		auxp = new ArrayList<>();
		auxp.add(new Pieza("Panel superior"));
		auxp.add(new Pieza("Tornillo sujeción"));
		auxh = new ArrayList<>();
		auxh.add(new Herramienta("Galgas de medición"));
		auxh.add(new Herramienta("Martillo"));
		auxh.add(new Herramienta("Carraca"));
		Mantenimiento aux2 = new Mantenimiento("Cambio del panel superior", auxp, auxh, 2, 10);
		res.add(aux2);
		return new PartesAvion("Alerones", res);
	}

	private static PartesAvion defineFlaps() {
		ArrayList<Pieza> auxp = new ArrayList<>();
		ArrayList<Herramienta> auxh = new ArrayList<>();
		ArrayList<Mantenimiento> res = new ArrayList<>();

		auxp.add(new Pieza("Aceite", 500));
		auxh.add(new Herramienta("Alicate"));
		auxh.add(new Herramienta("Destornillador"));
		Mantenimiento aux = new Mantenimiento("Engrasado de flaps", auxp, auxh, 2, 6);
		res.add(aux);

		auxp = new ArrayList<>();
		auxp.add(new Pieza("Pistón"));
		auxp.add(new Pieza("Tornillo sujeción"));
		auxh = new ArrayList<>();
		auxh.add(new Herramienta("Berbiquí"));
		auxh.add(new Herramienta("Espejos"));
		auxh.add(new Herramienta("Carraca"));
		Mantenimiento aux2 = new Mantenimiento("Cambio de pistones de los flaps", auxp, auxh, 3, 15);
		res.add(aux2);
		return new PartesAvion("Flaps", res);
	}

	private static PartesAvion defineSpoilers() {
		ArrayList<Pieza> auxp = new ArrayList<>();
		ArrayList<Herramienta> auxh = new ArrayList<>();
		ArrayList<Mantenimiento> res = new ArrayList<>();

		auxp.add(new Pieza("Aceite", 200));
		auxh.add(new Herramienta("Alicate"));
		auxh.add(new Herramienta("Destornillador"));
		Mantenimiento aux = new Mantenimiento("Engrasado de spoilers", auxp, auxh, 2, 5);
		res.add(aux);

		auxp = new ArrayList<>();
		auxp.add(new Pieza("Pistón"));
		auxp.add(new Pieza("Tuerca sujeción"));
		auxh = new ArrayList<>();
		auxh.add(new Herramienta("Berbiquí"));
		auxh.add(new Herramienta("Espejos"));
		auxh.add(new Herramienta("Carraca"));
		Mantenimiento aux2 = new Mantenimiento("Cambio de pistones de los spoilers", auxp, auxh, 3, 20);
		res.add(aux2);
		return new PartesAvion("Spoilers", res);
	}

	private static PartesAvion defineFrenos() {
		ArrayList<Pieza> auxp = new ArrayList<>();
		ArrayList<Herramienta> auxh = new ArrayList<>();
		ArrayList<Mantenimiento> res = new ArrayList<>();
		auxp.add(new Pieza("Pieza sujeción"));
		auxp.add(new Pieza("Tornillo sujeción"));
		auxh.add(new Herramienta("Destornillador"));
		auxh.add(new Herramienta("Trenzador"));
		Mantenimiento aux = new Mantenimiento("Cambio de sujeciones", auxp, auxh, 1, 3);
		res.add(aux);
		return new PartesAvion("Frenos aerodinámicos", res);
	}

	private static PartesAvion defineSlats() {
		ArrayList<Pieza> auxp = new ArrayList<>();
		ArrayList<Herramienta> auxh = new ArrayList<>();
		ArrayList<Mantenimiento> res = new ArrayList<>();
		auxp.add(new Pieza("Aceite", 100));
		auxh.add(new Herramienta("Alicate"));
		auxh.add(new Herramienta("Destornillador"));
		Mantenimiento aux = new Mantenimiento("Engrasado de slats", auxp, auxh, 1, 3);
		res.add(aux);

		auxp = new ArrayList<>();
		auxp.add(new Pieza("Pistón"));
		auxp.add(new Pieza("Tuerca sujeción"));
		auxh = new ArrayList<>();
		auxh.add(new Herramienta("Berbiquí"));
		auxh.add(new Herramienta("Espejos"));
		auxh.add(new Herramienta("Carraca"));
		Mantenimiento aux2 = new Mantenimiento("Cambio de pistones de los slats", auxp, auxh, 3, 9);
		res.add(aux2);
		return new PartesAvion("Slats", res);
	}

	public ArrayList<Mantenimiento> listaTareas() { // Crea una lista de mantenimientos para un avion
		ArrayList<Mantenimiento> tareas = new ArrayList<>();
		tareas.addAll(alerones.getTarea());
		tareas.addAll(flaps.getTarea());
		tareas.addAll(spoilers.getTarea());
		tareas.addAll(frenosAerodinamicos.getTarea());
		tareas.addAll(slats.getTarea());
		return tareas;
	}

	private int restando(int total, int parcial) { // Evita numeros negativos
		int aux;
		if (total >= parcial) {
			aux = parcial;
		} else {
			aux = total;
		}
		return aux;
	}

	/**
	 * @author Julio Semper Función de comprobación de piezas, herramientas y
	 *         plantilla sobre el avión creado
	 * @param piezas       Lista de piezas dadas por el usuario
	 * @param herramientas Lista de herramientas dadas por el usuario
	 * @param personas     Lista de plantilla aportada por el usuario
	 * 
	 *                     Modificacion realizada: Ahora el programa identifica qué
	 *                     tareas no se pueden realizar con el input del usuario
	 */
	public void compruebaRecursos(ArrayList<Pieza> piezas, ArrayList<Herramienta> herramientas,
			ArrayList<Personal> personas) {
		ArrayList<String> piezasSkip = new ArrayList<>();
		ArrayList<String> piezasNombre = new ArrayList<>();
		ArrayList<String> herramientasSkip = new ArrayList<>();
		ArrayList<String> herramientasNombre = new ArrayList<>();
		ArrayList<String> ofiSkip = new ArrayList<>();
		ArrayList<String> opSkip = new ArrayList<>();
		int aux;
		int pendientesOp = 1; // ESTE CONTADOR ME PERMITE VER SI NO HAY SUFICIENTES OPERARIOS EN PLANTILLA
		int pendientesOfi = 1; // ESTE CONTADOR ME PERMITE VER SI NO HAY SUFICIENTES OFICIALES EN PLANTILLA

		for (Mantenimiento tarea : this.listaTareas()) { // Recorrer tareas
			for (Pieza piezaTarea : tarea.getPiezas()) { // Recorres piezas de la tarea
				for (Pieza pieza : piezas) { // buscar pieza en array de piezas
					if (piezaTarea.getTipoPieza().contentEquals(pieza.getTipoPieza()) && !(pieza.isEnUso())
							&& !(piezaTarea.isEnUso())) {
						pieza.setEnUso(true);
						piezaTarea.setEnUso(true);
						pieza.setTareaEnUso(tarea.getNombre());
					}
					if (piezaTarea.getTipoPieza() == "Aceite"
							&& pieza.getCantidadAceite() >= piezaTarea.getCantidadAceite()) {
						piezaTarea.setCantidadAceite(piezaTarea.getCantidadAceite() - pieza.getCantidadAceite());
						pieza.setEnUso(true);
						piezaTarea.setEnUso(true);
					}
				}
				if (!(piezaTarea.isEnUso())) { // NO SE SI ESTO SOBRA
					piezasSkip.add(piezaTarea.getTipoPieza());
					piezasNombre.add(tarea.getNombre());
				}
			}

			for (Herramienta herramientaTarea : tarea.getHerramientas()) { // Recorres herramientas de la tarea
				for (Herramienta herramienta : herramientas) { // Busca la herramienta adecuada en el array de
																// herramientas
					if (herramientaTarea.getTipoHerramienta().contentEquals(herramienta.getTipoHerramienta())
							&& !(herramienta.isEnUso()) && !(herramientaTarea.isEnUso())) {
						herramienta.setEnUso(true);
						herramientaTarea.setEnUso(true);
						herramienta.setTareaEnUso(tarea.getNombre());
					}
				}
				if (!(herramientaTarea.isEnUso())) { // NO SE SI ESTO SOBRA
					herramientasSkip.add(herramientaTarea.getTipoHerramienta());
					herramientasNombre.add(tarea.getNombre());
				}
			}

			for (Personal persona : personas) {
				pendientesOfi = tarea.getHorasOficial();
				pendientesOp = tarea.getHorasOperario();
				if (persona.getCargoEmpresa() == true && pendientesOfi > 0 && !(persona.isOcupado())) {
					// Busca todos los oficiales vistos en plantilla para esta tarea
					aux = this.restando(tarea.getHorasOficial(), persona.getHoras());
					// Evita números negativos restando el menor de los dos numeros
					persona.setHoras(persona.getHoras() - aux);
					tarea.setHorasOficial(tarea.getHorasOficial() - aux);
					if (persona.getHoras() == 0) {
						persona.setOcupado(true);
					}
					pendientesOfi = tarea.getHorasOficial();
				} else {
					ofiSkip.add(tarea.getNombre());
				}
				if (persona.getCargoEmpresa() != true && pendientesOp > 0 && !(persona.isOcupado())) {
					aux = this.restando(tarea.getHorasOperario(), persona.getHoras()); // Evita números negativos
																						// restando el menor de los dos
																						// numeros
					persona.setHoras(persona.getHoras() - aux);
					tarea.setHorasOperario(tarea.getHorasOperario() - aux);
					if (persona.getHoras() == 0) {
						persona.setOcupado(true);
					}
					pendientesOp = tarea.getHorasOperario();
				} else {
					opSkip.add(tarea.getNombre());
				}
			}
		}
		for (String piezasFaltantes : piezasSkip) {
			System.out.println("No ha habido suficientes " + piezasFaltantes + " para la tarea "
					+ piezasNombre.indexOf(piezasFaltantes));
		}

		for (String herramientasFaltantes : herramientasSkip) {
			System.out.println("No ha habido suficientes " + herramientasFaltantes + " para la tarea "
					+ herramientasNombre.indexOf(herramientasFaltantes));
		}
		for (String oficialesFaltantes : ofiSkip) {
			System.out.println("No ha habido suficientes oficiales para la tarea " + oficialesFaltantes);
		}

		for (String operariosFaltantes : opSkip) {
			System.out.println("No ha habido suficientes operarios para la tarea " + operariosFaltantes);
		}

		if (piezasSkip.isEmpty() && herramientasSkip.isEmpty() && ofiSkip.isEmpty() && opSkip.isEmpty()) {
			System.out.println("Se han realizado todas las tareas de mantenimiento del avión " + this.matricula
					+ " sin mayor incidencia");
		}
	}
}
