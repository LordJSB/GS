package practica7_POO1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in).useDelimiter("\r\n");
		System.out.println("Bienvenido al sistema de mantenimiento de AENA");
//		ArrayList<Pieza> stockPiezas = stockPiezas();
//		ArrayList<Herramienta> stockHerramientas = stockHerramientas();
//		ArrayList<Personal> plantilla = altaPlantilla();

		ArrayList<Pieza> sP = stockP();
		ArrayList<Herramienta> sH = stockH();
		ArrayList<Personal> pl = stockPl();
		System.out.print("Por último, introduzca la matrícula del avión: ");
		Avion ejemplo = new Avion(teclado.next());
		ejemplo.compruebaRecursos(sP, sH, pl);
		teclado.close();
	}

///////////////////////////METODOS PARA AÑADIR EL STOCK POR PARTE DEL USUARIO///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * @author Julio Semper Función de inserción de piezas insertadas por teclado
	 * 
	 * 
	 *         Modificacion realizada: Ahora al insertar algo que no sea un numero
	 *         en la cantidad de piezas, no colapsa el programa y vuelve a preguntar
	 *         al usuario
	 */
	public static ArrayList<Pieza> stockP() {
		Scanner teclado = new Scanner(System.in);
		teclado.useDelimiter("\r\n");
		String nombre, continuar;
		int cantidad;
		boolean seguir = true;
		ArrayList<Pieza> stock = new ArrayList<>();
		Pieza aux = null;

		System.out.println("Ahora se establecerá el stock disponible de piezas para el mantenimiento de los aviones.");
		System.out.println("Las piezas disponibles son: " + new Pieza().getListaAutorizada());
		do {
			System.out.print("Inserte el nombre de la pieza a añadir al stock del mantenimiento: ");
			nombre = compruebaPiezas(teclado, "Inserte el nombre de la pieza: ");
			if (nombre == "Aceite") {
				cantidad = compruebaNumeros(teclado, "¿Cuántos mililitros de aceite se van a guardar?");
				aux = new Pieza(nombre, cantidad);
				stock.add(aux);
			} else {
				cantidad = compruebaNumeros(teclado, "¿Cuántas " + nombre + "se van a guardar?");
				for (int i = 0; i < cantidad; i++) {
					aux = new Pieza(nombre);
					stock.add(aux);
				}
			}
			if (aux.getTipoPieza() == "ERROR") { // Vease serTipoPieza() en la clase Pieza.java TERMINA DE CORREGIR ESTO
				System.out.println("Debido al error debe introducir una pieza válida");
			} else {
				System.out.print("¿Desea añadir otra pieza? Si es así, escriba 'si': ");
				continuar = teclado.next();
				if (continuar.equalsIgnoreCase("si")) {
					System.out.println("Alojando más espacio en el almacén de piezas...");
				} else if (continuar.equalsIgnoreCase("no")) {
					System.out.println("Distribuyendo las piezas actuales...\nOK\n");
					seguir = false;
				}
			}
		} while (seguir);
		return stock;
	}

	/**
	 * @author Julio Semper Función de inserción de herramientas insertadas por
	 *         teclado
	 * 
	 * 
	 *         Modificacion realizada: Ahora al insertar algo que no sea un numero
	 *         en la cantidad de herramientas, no colapsa el programa y vuelve a
	 *         preguntar al usuario
	 */
	public static ArrayList<Herramienta> stockH() {
		Scanner teclado = new Scanner(System.in);
		teclado.useDelimiter("\r\n");
		String nombre, continuar;
		int cantidad;
		boolean seguir = true;
		ArrayList<Herramienta> stock = new ArrayList<>();
		Herramienta aux = null;

		System.out.println(
				"Ahora se establecerá el stock disponible de herramientas para el mantenimiento de los aviones.");
		System.out.println("Las herramientas disponibles son: " + new Herramienta().getListaAutorizada());
		do {
			System.out.print("Inserte el nombre de la herramienta a añadir al stock del mantenimiento: ");
			nombre = compruebaHerramientas(teclado, "Inserte el nombre de la herramienta: ");
			cantidad = compruebaNumeros(teclado, "¿Cuántas " + nombre + " se van a guardar");
			for (int i = 0; i < cantidad; i++) {
				aux = new Herramienta(nombre);
				stock.add(aux);
			}
			if (aux.getTipoHerramienta() != "ERROR") { // Vease serTipoHerramienta() en la clase Herramienta.java
				System.out.print("¿Desea añadir otra herramienta? Si es así, escriba 'si': ");
				continuar = teclado.next();
				if (continuar.equalsIgnoreCase("si")) {
					System.out.println("Alojando más espacio en el almacén de piezas...");
				} else if (continuar.equalsIgnoreCase("no")) {
					System.out.println("Distribuyendo las piezas actuales...\nOK\n");
					seguir = false;
				}
			}
		} while (seguir);
		return stock;
	}

	public static ArrayList<Personal> stockPl() {
		@SuppressWarnings("resource") // No se emplea el uso de Scanner.close() debido a que no permite el uso de
										// Scanner a futuros metodos
		Scanner teclado = new Scanner(System.in);
		teclado.useDelimiter("\r\n");
		boolean seguir = true;
		String nombre, apellido, continuar, car;
		boolean cargo = false;
		boolean isValid = true;
		ArrayList<Personal> plantilla = new ArrayList<>();

		System.out.println(
				"Por último se establecerá la plantilla de la jornada actual encargada del mantenimiento de los aviones.");
		do {
			System.out.print("Inserte el nombre del trabajador: ");
			nombre = teclado.next();
			System.out.print("Inserte los apellidos del trabajador: ");
			apellido = teclado.next();
			do {
				System.out.print("¿Este empleado es un oficial?: ");
				car = teclado.next();
				if (car.equalsIgnoreCase("si")) {
					cargo = true;
					isValid = true;
				} else if (car.equalsIgnoreCase("no")) {
					cargo = false;
					isValid = true;
				} else {
					System.out.println(
							"ERROR: responda con un 'si' o un 'no' a la pregunta");
					isValid = false;
				}
			} while (!isValid);
			Personal aux = new Personal(nombre, apellido, cargo, 8);
			plantilla.add(aux);
			System.out.print("¿Desea añadir otro trabajador? Si es así, escriba 'si': ");
			continuar = teclado.next();
			if (continuar.equalsIgnoreCase("si")) {
				System.out.println("Informando a " + aux.getNombre() + " " + aux.getApellidos() + "...");
			} else {
				System.out.println("Reuniendo los empleados necesarios...\nOK\n");
				seguir = false;
			}
		} while (seguir);
		return plantilla;
	}

//////////////////////////METODOS PARA AÑADIR EL STOCK POR PARTE DEL USUARIO///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@SuppressWarnings("resource")
	public static int compruebaNumeros(Scanner sc, String algo) {
		int x = 0;
		boolean seguir = false;
		do {
			sc = new Scanner(System.in);
			System.out.println(algo);
			if (sc.hasNextInt()) {
				x = sc.nextInt();
				seguir = true;
			} else {
				System.out.println("ERROR: introduce un entero");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}

	@SuppressWarnings("resource")
	public static String compruebaPiezas(Scanner sc, String algo) {
		String x = new Pieza().getListaAutorizada();
		boolean seguir = false;
		do {
			sc = new Scanner(System.in);
			System.out.println(algo);
			if (sc.next().contains(x)) {
				x = sc.nextLine();
				seguir = true;
			} else {
				System.out.println("ERROR: introduzca una pieza válida");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}

	@SuppressWarnings("resource")
	public static String compruebaHerramientas(Scanner sc, String algo) {
		String x = new Herramienta().getListaAutorizada();
		boolean seguir = false;
		do {
			sc = new Scanner(System.in);
			System.out.println(algo);
			if (sc.next().contains(x)) {
				x = sc.nextLine();
				seguir = true;
			} else {
				System.out.println("ERROR: introduzca un entero");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}
//////////////////////////METODOS ESTATICOS. NO USAR/////////////////////////////////////////////////////////////////////////////////////
//	private static ArrayList<Pieza> stockPiezas() {
//		ArrayList<Pieza> aux = new ArrayList<>();
//		Pieza aceite = new Pieza("Aceite", 1000);
//		aux.add(aceite);
//		Pieza tornilloSujecion = new Pieza("Tornillo sujeción", 3);
//		aux.add(tornilloSujecion);
//		Pieza tuercaSujecion = new Pieza("Tuerca sujeción", 2);
//		aux.add(tuercaSujecion);
//		Pieza piston = new Pieza("Pistón", 3);
//		aux.add(piston);
//		Pieza panelSuperior = new Pieza("Panel superior", 1);
//		aux.add(panelSuperior);
//		Pieza piezaSujecion = new Pieza("Pieza sujeción", 1);
//		aux.add(piezaSujecion);
//		return aux;
//	}
//
//	private static ArrayList<Herramienta> stockHerramientas() {
//		ArrayList<Herramienta> aux = new ArrayList<>();
//		Herramienta carraca = new Herramienta("Carraca", 5);
//		aux.add(carraca);
//		Herramienta alicate = new Herramienta("Alicate", 4);
//		aux.add(alicate);
//		Herramienta destornillador = new Herramienta("Destornillador", 4);
//		aux.add(destornillador);
//		Herramienta berbequi = new Herramienta("Berbiquí", 3);
//		aux.add(berbequi);
//		Herramienta martillo = new Herramienta("Martillo", 1);
//		aux.add(martillo);
//		Herramienta espejo = new Herramienta("Espejos", 3);
//		aux.add(espejo);
//		Herramienta trenzador = new Herramienta("Trenzador", 1);
//		aux.add(trenzador);
//		Herramienta galga = new Herramienta("Galgas de medición", 1);
//		aux.add(galga);
//		return aux;
//	}
//
//	private static ArrayList<Personal> altaPlantilla() {
//		ArrayList<Personal> aux = new ArrayList<>();
//		Personal op1 = new Personal("Operario1", "Uno", false, 8);
//		aux.add(op1);
//		Personal op2 = new Personal("Operario2", "Dos", false, 8);
//		aux.add(op2);
//		Personal op3 = new Personal("Operario3", "Tres", false, 8);
//		aux.add(op3);
//		Personal op4 = new Personal("Operario4", "Cuatro", false, 8);
//		aux.add(op4);
//		Personal op5 = new Personal("Operario5", "Cinco", false, 8);
//		aux.add(op5);
//		Personal op6 = new Personal("Operario6", "Seis", false, 8);
//		aux.add(op6);
//		Personal op7 = new Personal("Operario7", "Siete", false, 8);
//		aux.add(op7);
//		Personal op8 = new Personal("Operario8", "Ocho", false, 8);
//		aux.add(op8);
//		Personal op9 = new Personal("Operario9", "Nueve", false, 8);
//		aux.add(op9);
//		Personal op10 = new Personal("Operario10", "Diez", false, 3);
//		aux.add(op10);
//		Personal ofi1 = new Personal("Oficial1", "Uno", true, 8);
//		aux.add(ofi1);
//		Personal ofi2 = new Personal("Oficial2", "Dos", true, 8);
//		aux.add(ofi2);
//		Personal ofi3 = new Personal("Oficial3", "Tres", true, 3);
//		aux.add(ofi3);
//		return aux;
//	}
//////////////////////////METODOS ESTATICOS. NO USAR/////////////////////////////////////////////////////////////////////////////////////
}