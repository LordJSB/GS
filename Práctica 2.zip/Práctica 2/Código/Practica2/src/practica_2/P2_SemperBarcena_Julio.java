package practica_2;

import java.util.Scanner;

public class P2_SemperBarcena_Julio {

	public static void main(String args[]) {
		final String ALFABETO = "sinoSINO"; // Este string nos permite identificar únicamente las palabras "si" y "no"
		int numeroRandom = (int) (Math.random() * 100); // Generador de número aleatorio
		@SuppressWarnings("resource")
		Scanner teclado = new Scanner(System.in);
		boolean finish = false; // Condición de bucle
		System.out.println("Bienvenido a la 23ª edición de HigherLower\u00a9. " // Mensaje de bienvenida
				+ "\nSe ha generado un número del 0 al 100 " + "\nIntroduzca un número:");

		while (!finish) {
			if (!teclado.hasNextInt()) { // Comprobamos que el usuario inserta un número
				System.out.println("Error: inserte un número natural");
				return;
			}
			int numUser = teclado.nextInt(); // Asignamos el valor del número insertado como variable
			if (numUser < 0 || numUser > 100) { // Nos aseguramos que el número insertado es entre 0 y 100
				System.out.println("Inserte un número entre 0 y 100");
				return;
			}
			if (numUser < numeroRandom) { // Si el número insertado por el usuario es menor al generado aleatoriamente
				System.out.println(
						"Lo siento, pero tu número es menor del que he pensado\n" + "¿Quieres volver a intentarlo?");
				String userInput = teclado.next();
				for (int i = 0; i < userInput.length(); i++) { // comprobación de inputs validos
					if (ALFABETO.indexOf(userInput.charAt(i)) < 0 || userInput.length() < 2) { // Nos aseguramos que
																								// incluya las palabras
																								// si o no
						System.out.println("Error: Responda con un si o un no");
						return;
					}
				}

				if (userInput.toLowerCase().equals("si")) { // En caso de que el usuario quiera seguir, continuamos sin
															// problemas
					System.out.println("Escoge otro número");
				} else if (userInput.toLowerCase().equals("no")) { // Si el usuario quiere parar, incumplimos el
																	// condicional inherente a while para salir del
																	// bucle
					System.out.println("Una pena, me lo estaba pasando genial. ¡Hasta otra!");
					finish = true;
				}

			} else if (numUser > numeroRandom) {
				System.out.println("Mala suerte, tu número es mayor que el que yo había pensado\n"
						+ "¿Quieres volver a intentarlo?");
				String userInput = teclado.next();
				for (int i = 0; i < userInput.length(); i++) { // comprobación de inputs validos
					if (ALFABETO.indexOf(userInput.charAt(i)) < 0 || userInput.length() < 2) { // Nos aseguramos que
																								// incluya las palabras
																								// si o no
						System.out.println("Error: Responda con un si o un no");
						return;
					}
				}

				if (userInput.toLowerCase().equals("si")) { // En caso de que el usuario quiera seguir, continuamos sin
															// problemas
					System.out.println("Prueba con otro número");
				} else if (userInput.toLowerCase().equals("no")) { // Si el usuario quiere parar, incumplimos el
																	// condicional inherente a while para salir del
																	// bucle
					System.out.println("Vaya, ¿ya te vas?. ¡Nos vemos!");
					finish = true;
				}

			} else {
				System.out.println("¡Enhorabuena, has acertado!\n" + "¿Quieres volver a intentarlo?");
				String userInput = teclado.next();
				for (int i = 0; i < userInput.length(); i++) { // comprobación de inputs validos
					if (ALFABETO.indexOf(userInput.charAt(i)) < 0 || userInput.length() < 2) { // Nos aseguramos que
																								// incluya las palabras
																								// si o no
						System.out.println("Error: Responda con un si o un no");
						return;
					}
				}

				if (userInput.toLowerCase().equals("si")) { // Si el usuario inicia "una nueva partida" generamos un
															// nuevo número
					numeroRandom = (int) (Math.random() * 100);
					System.out.println("Se ha generado otro número aleatorio.\nInserte un número del 0 al 100:");
				} else if (userInput.toLowerCase().equals("no")) { // Si el usuario quiere parar, incumplimos
																	// el condicional inherente a while para salir
																	// del bucle
					System.out.println("Ha sido un placer jugar contigo. ¡Adios!");
					finish = true;
				}
			}

		}
	}
}