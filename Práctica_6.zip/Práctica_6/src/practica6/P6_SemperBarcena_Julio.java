package practica6;

import java.util.Scanner;
import java.util.regex.*;

public class P6_SemperBarcena_Julio {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in).useDelimiter("\r\n");
		String entrada = "";
		int selector = 0;

		System.out.println("Bienvenido. Este programa contiene 10 expresiones regulares para ser puestas a prueba.\n");
		System.out.println("Primera expresión: valida la palabra 'color' tanto en inglés como en español");
		System.out.println("Segunda expresión: encuentre las palabras 'Buenos días' o 'Buenas tardes' en un texto");
		System.out.println("Tercera expresión: valida la palabra 'google' con, al menos, una 'o'");
		System.out.println("Cuarta expresión: valida un número de teléfono de Madrid");
		System.out.println("Quinta expresión: valida un código postal de Alcalá de Henares");
		System.out.println("Sexta expresión: comprueba si un texto finaliza con 'adiós'");
		System.out.println("Séptima expresión: comprueba si se ha insertado un número de 11 dígitos que empiece por '1'");
		System.out.println("Octava expresión: comprueba si un número está entre 0 y 1");
		System.out.println("Novena expresión: valida si un apellido acaba en 'ez'");
		System.out.println("Décima expresión: custom\n\n");
		System.out.print("Inserte el contenido a evaluar: ");

		entrada = teclado.next();
		System.out.print("\nInserte el número de la expresión que quiera usar: ");
		do {
			if (teclado.hasNextInt()) {
				selector = teclado.nextInt();
			} else {
				System.out.println("Error: Debe introducir un número del 1 al 10");
				teclado.next();
			}
		} while (!(compruebaNumeros(selector)));
		teclado.close();

		switch (selector) {
		case 1:
			patronUno(entrada);
			break;
		case 2:
			patronDos(entrada);
			break;
		case 3:
			patronTres(entrada);
			break;
		case 4:
			patronCuatro(entrada);
			break;
		case 5:
			patronCinco(entrada);
			break;
		case 6:
			patronSeis(entrada);
			break;
		case 7:
			patronSiete(entrada);
			break;
		case 8:
			patronOcho(entrada);
			break;
		case 9:
			patronNueve(entrada);
			break;
		default:
			patronDiez(entrada);
			break;
		}
	}

	private static void patronUno(String entrada) {
		Pattern patron = Pattern.compile("[c|C]+olo[u]?+r");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el primer patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el primer patrón");
		}

	}

	private static void patronDos(String entrada) {
		Pattern patron = Pattern.compile(".*[B|b]uenos[\s]{1}d[i|í]{1}as.*|.*[B|b]uenas[\s]{1}tardes.*");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el segundo patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el segundo patrón");
		}

	}

	private static void patronTres(String entrada) {
		Pattern patron = Pattern.compile("g[o]+gle");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el tercer patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el tercer patrón");
		}

	}

	private static void patronCuatro(String entrada) {
		Pattern patron = Pattern.compile("[9|8]{1}[1]{1}[\\d]{7}");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el cuarto patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el cuarto patrón");
		}

	}

	private static void patronCinco(String entrada) {
		Pattern patron = Pattern.compile("2880[1-7]{1}");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el quinto patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el quinto patrón");
		}

	}

	private static void patronSeis(String entrada) {
		Pattern patron = Pattern.compile(".*adiós$"); 	
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el sexto patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el sexto patrón");
		}

	}

	private static void patronSiete(String entrada) {
		Pattern patron = Pattern.compile("1\\d{10}");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el séptimo patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el séptimo patrón");
		}

	}

	private static void patronOcho(String entrada) { 
		Pattern patron = Pattern.compile("0{1,}[.,]{1}[\\d]*|[10]");
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el octavo patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el octavo patrón");
		}

	}

	private static void patronNueve(String entrada) {
		Pattern patron = Pattern.compile(".*[A-Z]{1}[\\D]*ez.*"); 
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {	
			System.out.println("La entrada recibida coincide con el noveno patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el noveno patrón");
		}

	}

	private static void patronDiez(String entrada) {
		Pattern patron = Pattern.compile(".*[P|p]anificadora.*"); 
		Matcher coincidencia = patron.matcher(entrada);
		if (coincidencia.matches()) {
			System.out.println("La entrada recibida coincide con el décimo patrón");
		} else {
			System.out.println("La entrada recibida no coincide con el décimo patrón");
		}

	}

	private static boolean compruebaNumeros(int entrada) {
		if (entrada < 1 || entrada > 10) {
			System.out.print("\nError: no se ha seleccionado una expresión disponible.\nInserte otro número: ");
			return false;
		} else {
			return true;
		}
	}
}
