package Package_POO01;

public class clasePrincipal {

	public static void main(String[] args) {

		Calendario mariaAuxiliar = new Calendario(9, 1, 2023, "Maria Auxiliadora", "Llena");
		System.out.println("El dia de hoy en el calendario de Maria es: " + mariaAuxiliar.getDiaCal());

		Calendario deportesChema = new Calendario();
		System.out.println("El dia de hoy en el calendario de Chema es: " + deportesChema.getDiaCal());

		Calendario piensosJacinto = new Calendario(6, 9, 420);
		System.out.println("El dia de hoy en el calendario de Jacinto es: " + piensosJacinto.getDiaCal());

		mariaAuxiliar.setDiaCal(13);
		System.out.println(
				"Ahora me he inventado que es " + mariaAuxiliar.getDiaCal() + " XDXDXDXDXDXDXDXDXDXDXDXDXDXDXDXD");

		piensosJacinto.setLuna("amarilla");
		System.out.println("Jacinto tiene la luna " + piensosJacinto.getLuna());

		piensosJacinto.multisetter(31, 12, 2023, "Nochevieja", "Ebria");
		System.out.println("La fecha es: " + piensosJacinto.getDiaCal() + "/" + piensosJacinto.getMes() + "/"
				+ piensosJacinto.getAnio() + " con la luna en " + piensosJacinto.getLuna() + " y la foto de "
				+ piensosJacinto.getFoto());

	}

}
