package Package_POO01;

public class Calendario {
	
	private int dia = 0;
	private int mes = 0;
	private int anio = 0;
	private String foto = "MAX";
	private String luna = "Hay_luna";
	
	public Calendario(){} //El constructor de Chema
	
	public Calendario (int dia, int mes, int anio) { //El constructor de Jacinto
		this.dia = dia;
		this.mes = mes;
		this.anio = anio;
	}
	
	public Calendario (int dia, int mes, int anio, String foto, String luna) { //Constructor de maria
		
		this.dia = dia;
		this.mes = mes;
		this.anio = anio;
		this.foto = foto;
		this.luna = luna;
	}
	
	public int getDiaCal() {return dia;}
	public void setDiaCal(int Ndia) {dia = Ndia;}
	
	public int getMes() {return mes;}
	public void setMes(int mes) {this.mes = mes;}

	public int getAnio() { return anio;}
	public void setAnio(int anio) {this.anio = anio;}

	public String getFoto() {return foto;}
	public void setFoto(String foto) {this.foto = foto;}

	public String getLuna() {return luna;}
	public void setLuna(String luna) {this.luna = luna;}


	public void multisetter (int dia, int mes, int anio, String foto, String luna) { 
		this.dia = dia;
		this.mes = mes;
		this.anio = anio;
		this.foto = foto;
		this.luna = luna;
	}
}
