package practica_1;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class P1_Semper_Barcena_Julio {

	/**
	 * @param Declaración de variables
	 */
	public static void main(String args[]) {
		final String ALFABETO = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";// Con esta constante
																									// string nos
																									// aseguramos que
																									// los nombres de
																									// los alumnos son
																									// nombres válidos
		byte porcentajeExamen = 0; // Porcentaje de evaluación para los examenes
		byte porcentajePractica = 0; // Porcentaje de evaluación para las prácticas
		byte porcentajeAsistencia = 0; // Porcentaje de evaluación para la asistencia
		byte cantidadAlumno = 0; // Número de alumnos totales
		byte alumnoActual = 0; // Contador con el alumno actual
		float notaExamen = 0; // Nota numérica natural del examen con decimales entre 0 y 10 del alumno
		float notaPracticas = 0; // Nota numérica natural de las prácticas con decimales entre 0 y 10 del alumno
		float notaAsistencia = 0; // Nota numérica natural de la asistencia con decimales entre 0 y 10 del alumno
		float notaAlumno = 0; // Nota final del alumno tras aplicar los porcentajes de evaluación
		float notaTop = 0; // Nota máxima de la clase
		float notaBot = 10; // Nota mínima de la clase
		float notaMedia = 0; // Nota media de todos los alumnos de la clase
		String nombreAlumno = ""; // Nombre del alumno
		String nombreAlumnoTop = ""; // Nombre del alumno con la nota más alta
		String nombreAlumnoBot = ""; // Nombre del alumno con la nota más baja
		float suspensos = 0; // Toda nota <5
		float aprobados = 0; // Toda nota 5 - 6,9
		float notables = 0; // Toda nota 7 - 8,9
		float sobresalientes = 0; // Toda nota >=9
		@SuppressWarnings("resource") // Evitamos problemas de compilación omitiendo cerrar individualmente cada
										// teclado del programa
		Scanner teclado = new Scanner(System.in); // Para leer los inputs del usuario
		DecimalFormat df = new DecimalFormat(); // Con esto nos permite formatear las notas para limitarlas a 2
												// decimales
		df.setMaximumFractionDigits(2);
		NumberFormat dfPorciento = NumberFormat.getPercentInstance();// Con esto podemos formatear los porcentajes de
																		// suspensos, aprobados, etc. de manera sencilla
		dfPorciento.setMinimumFractionDigits(2);

		System.out.println("Bienvenido, profesor\n" // Mensaje inicial
				+ "Inserte los porcentajes de evaluación sobre 100 en los siguientes mensajes:\n"
				+ "Porcentaje de exámenes: ");
		if (teclado.hasNextByte()) {
			porcentajeExamen = teclado.nextByte(); // Así evitamos que acepte un número decimal
		} else {
			System.out.println("Inserte un número entero entre 0 y 100");
			return;
		}
		if (porcentajeExamen < 0 || porcentajeExamen > 100) { // Comprobación de valores numéricos válidos para
																// porcentajes de examen
			System.out.println("Inserte un número entero entre 0 y 100");
			return;
		}
		System.out.println("\nPorcentaje de las prácticas: ");
		if (teclado.hasNextByte()) {
			porcentajePractica = teclado.nextByte(); // Así evitamos que acepte un número decimal
		} else {
			System.out.println("Inserte un número entero entre 0 y 100");
			return;
		}
		if (porcentajePractica < 0 || porcentajePractica > 100) { // Comprobación de valores válidos para porcentajes de
																	// práctica
			System.out.println("Inserte un número entero entre 0 y 100");
			return;
		}
		System.out.println("\nPorcentaje de la asistencia: ");
		if (teclado.hasNextByte()) {
			porcentajeAsistencia = teclado.nextByte(); // Así evitamos que acepte un número decimal
		} else {
			System.out.println("Inserte un número entero entre 0 y 100");
			return;
		}
		if (porcentajeAsistencia < 0 || porcentajeAsistencia > 100) { // Comprobación de valores válidos para
																		// porcentajes de asistencia
			System.out.println("Inserte un número entero entre 0 y 100");
			return;
		}
		if (porcentajeExamen + porcentajeAsistencia + porcentajePractica != 100) { // Comprobamos si el profesor no se
																					// ha liado con los porcentajes
			System.out.println("Error: el sumatorio de los porcentajes de evaluación no es 100");
			return;
		}

		System.out.println("Inserte la cantidad de alumnos a evaluar: ");
		if (teclado.hasNextByte()) {
			cantidadAlumno = teclado.nextByte(); // Comprobamos que el profesor ha metido un numero valido
		}
		if (cantidadAlumno <= 0) {
			System.out.println(
					"Error: compruebe que haya insertado un número natural en el número de alumnos(límite de 127)");
			return;
		}

		while (alumnoActual < cantidadAlumno) { // Bucle para insertar alumnos
			System.out.println("\nInserte el nombre del alumno " + (alumnoActual + 1) + ": ");
			nombreAlumno = teclado.next();
			for (int i = 0; i < nombreAlumno.length(); i++) { // Leemos el nombre del alumno
				if (ALFABETO.indexOf(nombreAlumno.charAt(i)) < 0) { // recorremos todo el alfabeto en búsqueda de
																	// coincidencias
					System.out.println("Error: no se permiten caracteres especiales"); // Si no coincide, no es un
																						// caracter valido
					return;
				}
			}
			alumnoActual++;

			System.out.println(
					"\nInserte la nota del examen de " + nombreAlumno + " (utilice comas para separar decimales): ");
			if (teclado.hasNextFloat()) {
				notaExamen = teclado.nextFloat();
			}
			if (notaExamen < 0 || notaExamen > 10) { // Mensaje de error en caso de no insertar números entre 0 y 10
				System.out.println("Error: la nota del alumno debe comprenderse entre el 0 y el 10");
				return;
			}
			System.out.println("\nInserte la nota de las prácticas de " + nombreAlumno + ":");
			if (teclado.hasNextFloat()) {
				notaPracticas = teclado.nextFloat();
			}
			if (notaPracticas < 0 || notaPracticas > 10) { // Mensaje de error en caso de no insertar números entre 0 y
															// 10
				System.out.println("Error: la nota del alumno debe comprenderse entre el 0 y el 10");
				return;
			}
			System.out.println("\nInserte la nota de la asistencia de " + nombreAlumno + ": ");
			if (teclado.hasNextFloat()) {
				notaAsistencia = teclado.nextFloat();
			}
			if (notaAsistencia < 0 || notaAsistencia > 10) { // Mensaje de error en caso de no insertar números entre 0
																// y 10
				System.out.println("Error: la nota del alumno debe comprenderse entre el 0 y el 10");
				return;
			}
			notaExamen = notaExamen * porcentajeExamen; // Aplicamos porcentajes de las notas recibidas para calcular el
														// total
			notaExamen = notaExamen / 100; // Debido a que los porcentajes son de tipo Byte, se aplica la división sobre
											// una variable tipo Float
			notaPracticas = notaPracticas * porcentajePractica; // Como ya hemos limitado en el input las notas máximas
																// y mínimas, no hace falta realizar un control de
																// excepciones aquí
			notaPracticas = notaPracticas / 100;
			notaAsistencia = notaAsistencia * porcentajeAsistencia;
			notaAsistencia = notaAsistencia / 100;

			notaAlumno = notaExamen + notaPracticas + notaAsistencia;
			System.out.println("\nLa nota final de " + nombreAlumno + " es de " + df.format(notaAlumno));
			if (notaAlumno < notaBot) { // Si el alumno tiene la menor nota, se apunta tanto la nota como su nombre
				nombreAlumnoBot = nombreAlumno;
				notaBot = notaAlumno;
			}
			if (notaAlumno > notaTop) { // Si el alumno tiene la mejor nota, se apunta tanto la nota como su nombre
				nombreAlumnoTop = nombreAlumno;
				notaTop = notaAlumno;
			}

			notaMedia = notaMedia + notaAlumno; // Vamos acumulando todas las notas obtenidas en la variable para su
												// posterior cálculo al finalizar el bucle

			System.out.println("La nota aproximada de " + nombreAlumno + " es de " + Math.round(notaAlumno)); // La nota
																												// se
																												// aproxima
																												// en el
																												// propio
																												// print

			switch (Math.round(notaAlumno)) { // Evaluaciones se hacen en notas aproximadas
			case 10:
			case 9:
				sobresalientes++;
				System.out.println("La calificación de " + nombreAlumno + " es SOBRESALIENTE");
				break;
			case 8:
			case 7:
				notables++;
				System.out.println("La calificación de " + nombreAlumno + " es NOTABLE");
				break;
			case 6:
			case 5:
				aprobados++;
				System.out.println("La calificación de " + nombreAlumno + " es APROBADO");
				break;
			default:
				suspensos++;
				System.out.println("La calificación de " + nombreAlumno + " es SUSPENSO");
			}
		}
		notaMedia = notaMedia / cantidadAlumno; // Finalmente calculamos la nota media de toda la clase

		System.out
				.println("\n\nLa nota máxima de la clase ha sido " + nombreAlumnoTop + " con un " + df.format(notaTop)); // Añadimos
																															// los
																															// saltos
																															// de
																															// linea
																															// para
																															// separar
																															// las
																															// resoluciones
																															// finales
		System.out.println("La nota más baja de la clase ha sido " + nombreAlumnoBot + " con un " + df.format(notaBot)); // de
																															// las
																															// notas
																															// del
																															// último
																															// alumno
		System.out.println("La nota media de la clase es de " + df.format(notaMedia));
		System.out.println("El porcentaje de suspensos es de " + dfPorciento.format(suspensos / cantidadAlumno));
		System.out.println("El porcentaje de aprobados es de " + dfPorciento.format(aprobados / cantidadAlumno));
		System.out.println("El porcentaje de notables es de " + dfPorciento.format(notables / cantidadAlumno));
		System.out.println(
				"El porcentaje de sobresalientes es de " + dfPorciento.format(sobresalientes / cantidadAlumno));
	}
}
