package practica3;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * @author julio.semper
 *
 */
public class P3_SemperBarcena_Julio {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner teclado = new Scanner(System.in); // Registro de la mayoría de inputs dadods por el usuario
		short numPacientes = 0; // Indica el número de pacientes dados por el usuario
		float alturaPaciente = 0; // Indica la altura del paciente
		float pesoPaciente = 0; // Indica el peso del paciente
		float IMC = 0; // Indica el Índice de Masa Corporal del paciente a través de la altura y el
						// peso del mismo
		float maxIMC = 0; // Se establece un IMC máximo muy bajo para que sea fácilmente recogido por el
							// primer o único input del usuario
		float minIMC = 1000; // Al igual que maxIMC, se establece un valor fácilmente sustituible por el
								// primer o único input del usuario
		float alturaMax = 0; // Igual funcionamiento que maxIMC
		float pesoMin = 1000; // Igual funcionamiento que minIMC
		float mediaPeso = 0; // Indica la media de peso de todos los pacientes dados por el usuario
		float mediaAltura = 0; // Indica la media de altura de todos los pacientes dados por el usuario
		int pesoBajo = 0; // Guarda la cantidad de pacientes con bajo peso indicado por su IMC
		int pesoMedio = 0; // Guarda la cantidad de pacientes con peso normal indicado por su IMC
		int pesoAlto = 0; // Guarda la cantidad de pacientes con sobrepeso indicado por su IMC
		int pesoMuyAlto = 0; // Guarda la cantidad de pacientes con obesidad indicado por su IMC
		String nomPaciente = ""; // Aquí se guarda el nombre del paciente con el que se introducirán los futuros
									// datos
		String nomPacienteDelgado = ""; // Indica el nombre del paciente con menor peso del grupo
		String nomPacienteAlto = ""; // Indica el nombre del paciente con mayor altura del grupo
		String nomPacienteMayorIMC = ""; // Indica el nombre del paciente con mayor IMC del grupo
		String nomPacienteMenorIMC = ""; // Indica el nombre del paciente con mayor IMC del grupo
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2); // Representación con 2 decimales sobre cualquier número decimal

		System.out.println("Bienvenido al registro del centro de salud Exemplum Nomen");
		do {
			System.out.print("Inserte el número de pacientes a evaluar: ");
			if (teclado.hasNextShort()) { // Comprobación de tipo adecuado
				numPacientes = teclado.nextShort();
				if (numPacientes <= 0) { // Mensaje de error en caso de números negativos
					System.out.println("Error: Debe introducir un valor numérico mayor de cero");
				}
			} else {
				System.out.println("Error: Debe introducir un valor numérico"); // Mensaje de error de un no-numero
				teclado.next();
			}
		} while (numPacientes <= 0);

		Scanner nombres = new Scanner(System.in).useDelimiter("\r\n"); // Este Scanner es de uso exclusivo para lectura
																		// de todo tipo de nombres, incluido nombres
																		// compuestos
		for (int i = 0; i < numPacientes; i++) {
			System.out.print("Inserte el nombre del paciente número " + (i + 1) + ": ");
			do {
				nomPaciente = nombres.next();
			} while (!(compruebaNombres(nomPaciente))); // Sólo continuará en el siguiente paso si se inserta un nombre
														// válido acorde al diccionario establecido en
														// "compruebaNombres"

			System.out.print("Inserte la altura de " + nomPaciente + " en metros: "); // Posible funcionalidad extra: si
																						// se inserta un número mayor de
																						// 20, considerarlo como CM y
																						// hacer conversión
			do {
				if (teclado.hasNextFloat()) {
					alturaPaciente = teclado.nextFloat();
				} else {
					System.out.println("Error: Debe introducir valores numérico");
					teclado.next();
				}
			} while (!(compruebaAlturaPaciente(alturaPaciente)));

			System.out.print("Inserte el peso de " + nomPaciente + " en kilogramos: ");
			do {
				if (teclado.hasNextFloat()) {
					pesoPaciente = teclado.nextFloat();
				} else {
					System.out.println("Error: Debe introducir valores numérico");
					teclado.next();
				}
			} while (!(compruebaPesoPaciente(pesoPaciente)));

			IMC = ((float) (pesoPaciente / Math.pow(alturaPaciente, 2))); // kg/m^2
			System.out.println(nomPaciente + " tiene un IMC de " + df.format(IMC));

			if (IMC < 18.5) { // Dependiendo del IMC del paciente, se le clasifica
				pesoBajo++;
			} else if (IMC > 18.5 && IMC < 25) {
				pesoMedio++;
			} else if (IMC > 25 && IMC < 40) {
				pesoAlto++;
			} else {
				pesoMuyAlto++;
			}
			if (IMC < minIMC) { // Si el IMC del paciente es menor que el menor IMC registrado, se guarda como
								// el nuevo récord
				minIMC = IMC;
				nomPacienteMenorIMC = nomPaciente;
			}
			if (IMC > maxIMC) { // Si el IMC del paciente es mayor que el mayor IMC registrado, se guarda como
								// el nuevo récord
				maxIMC = IMC;
				nomPacienteMayorIMC = nomPaciente;
			}
			if (alturaPaciente > alturaMax) { // Si la altura del paciente es mayor que la altura más alta registrada,
												// se guardará como el nuevo récord
				alturaMax = alturaPaciente;
				nomPacienteAlto = nomPaciente;
			}
			if (pesoPaciente < pesoMin) { // Si el peso del paciente es menor que el menor peso registrado,
											// se guardará como el nuevo récord
				pesoMin = pesoPaciente;
				nomPacienteDelgado = nomPaciente;
			}
			mediaPeso = calculadorMediaPeso(pesoPaciente, mediaPeso);
			mediaAltura = calculadorMediaAltura(alturaPaciente, mediaAltura);
		} // Fin de recogida de datos de pacientes
		nombres.close(); // Cerramos el scanner para los nombres aqui debido a un error de buffer en su
							// inclusión dentro del bucle donde se usa
		mediaPeso = mediaFinalPeso(mediaPeso, numPacientes);
		mediaAltura = mediaFinalAltura(mediaAltura, numPacientes);

		System.out.println(
				"\n" + nomPacienteDelgado + " es el paciente más delgado con " + df.format(pesoMin) + " kilos");
		System.out.println(nomPacienteAlto + " es el paciente más alto con " + df.format(alturaMax) + " metros");
		System.out.println(nomPacienteMayorIMC + " tiene el mayor IMC con " + df.format(maxIMC));
		System.out.println(nomPacienteMenorIMC + " tiene el menor IMC con " + df.format(minIMC));
		System.out.println("La media de peso de todos los pacientes es de " + df.format(mediaPeso) + " kilos");
		System.out.println("La media de altura de todos los pacientes es de " + df.format(mediaAltura) + " metros");
		if (pesoBajo != 1) { // Distinguimos entre 1 o múltiples pacientes para respetar la gramática
			System.out.println("Hay " + pesoBajo + " pacientes con bajo peso");
		} else {
			System.out.println("Hay " + pesoBajo + " paciente con bajo peso");
		}
		if (pesoMedio != 1) {
			System.out.println("Hay " + pesoMedio + " pacientes con peso normal");
		} else {
			System.out.println("Hay " + pesoMedio + " paciente con peso normal");
		}
		if (pesoAlto != 1) {
			System.out.println("Hay " + pesoAlto + " pacientes con sobrepeso");
		} else {
			System.out.println("Hay " + pesoAlto + " paciente con sobrepeso");
		}
		if (pesoMuyAlto != 1) {
			System.out.println("Hay " + pesoMuyAlto + " pacientes con obesidad");
		} else {
			System.out.println("Hay " + pesoMuyAlto + " paciente con obesidad");
		}
	}

	static boolean compruebaNombres(String nombre) { // función que comprueba si se inserta un nombre adecuado
		final String ALFABETO = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZáéíóúÁÉÍÓÚ ";
		for (int i = 0; i < nombre.length(); i++) {
			if (ALFABETO.indexOf(nombre.charAt(i)) < 0) {
				System.out.println("Error: se han detectado números en el nombre");
				System.out.print("Reinserte el nombre del paciente: ");
				return false;
			}
		}
		return true;
	}

	static boolean compruebaAlturaPaciente(float input) { // función que comprueba si se inserta una altura adecuada en
															// metros adecuada
		if (input < 0 || input > 3) {
			System.out.println("Error: Altura imposible");
			System.out.print("Inserte una altura válida (en metros): ");
			return false;
		} else {
			return true;
		}

	}

	static boolean compruebaPesoPaciente(float input) { // función que comprueba si se inserta un peso en kilos adecuado
		if (input < 0 || input > 300) {
			System.out.println("Error: Pesaje imposible");
			System.out.print("Inserte un peso válido (en kilogramos): ");
			return false;
		} else {
			return true;
		}
	}

	static float calculadorMediaPeso(float peso, float media) { // función que va sumando los pesos registrados para su
																// posterior cálculo
		media = media + peso;
		return media;
	}

	static float calculadorMediaAltura(float altura, float media) { // función que va sumando las alturas registrados
																	// para
																	// su posterior cálculo
		media = media + altura;
		return media;
	}

	static float mediaFinalPeso(float peso, float pacientes) { // cálculo final de la media de pesos de todos los
																// pacientes
		peso = peso / pacientes;
		return peso;
	}

	static float mediaFinalAltura(float altura, float pacientes) { // //cálculo final de la media de alturas de todos
																	// los pacientes
		altura = altura / pacientes;
		return altura;
	}
}
