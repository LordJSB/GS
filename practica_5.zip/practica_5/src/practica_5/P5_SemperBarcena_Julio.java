package practica_5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class P5_SemperBarcena_Julio {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		String s = "";
		String[] cadena = { "\s" };
		ArrayList<String> lista = new ArrayList<String>();

		System.out.println("Bienvenido a Cuenta-Palabras 2000 \u00a9 \nIntroduzca el texto a continuación: ");
		s = teclado.nextLine();
		cadena = s.split(" "); // Añadimos el contenido del "input" en forma de lista, siendo un elemento todo
								// aquel seguido de un espacio
		for (String c : cadena) {
			lista.add(c);
		}
		teclado.close();
		tamanioOracion(lista);
		palabraMasLarga(lista);
		isProgramacion(lista);
		miraLetrasAbecedario(lista);
		cuentaVocales(lista);
		reversor(lista);
		sustituyE(lista);
		contadorCaracteres(lista);
		contadorNumeros(lista);
	}

	private static void tamanioOracion(ArrayList<String> entrada) {
		if (entrada.size() != 1) { // size() devuelve el número de elementos de la lista
			System.out.println("\nEl texto contiene " + entrada.size() + " palabras");
		} else {
			System.out.println("\nEl texto contiene " + entrada.size() + " palabra");
		}
	}

	private static void palabraMasLarga(ArrayList<String> entrada) {
		String longestWord = "";
		for (int i = 0; entrada.size() > i; i++) { // Recorremos todos los elementos de la lista
			if (entrada.get(i).length() > longestWord.length()) { // Si el tamaño del elemento supera el de la palabra
																	// más larga guardada, se guarda esa palabra como la
																	// nueva palabra más larga
				longestWord = entrada.get(i);
			}
		}
		System.out.println("La palabra más larga es " + longestWord);
	}

	private static void isProgramacion(ArrayList<String> entrada) {
		if (entrada.contains("programación") || entrada.contains("programación.") || entrada.contains(",programación")
				|| entrada.contains("programación,")) { // Si se encuentra la palabra dentro de algún elemento, seguido
														// de puntos, comas o ninguno, se declarará como detectada
			System.out.println("El texto SI contiene la palabra 'programación' ");
		} else {
			System.out.println("El texto NO contiene la palabra 'programación' ");
		}
	}

	private static void miraLetrasAbecedario(ArrayList<String> entrada) {
		String alfabeto = "aábcdeéfghiíjklmnñoópqrstuúvwxyz";
		boolean visto;
		System.out.print("En el texto no aparecen las siguientes letras: ");
		for (char lector : alfabeto.toCharArray()) {
			visto = false; // Cada nueva palabra, restablecemos para que no detecte letras de más
			for (String lista : entrada) {
				for (char letra : lista.toLowerCase().toCharArray()) {
					if (letra == lector) {
						visto = true; // Si la ha visto, pues la ha visto
					}
				}
			}
			if (!visto) {
				System.out.print(lector + " "); // Imprime las letras no detectadas en la entrada
			}
		}
		System.out.print("\n");
	}

	private static void cuentaVocales(ArrayList<String> entrada) {
		final String VOCALES = "aeiouáéíóúAEIOUÁÉÍÓÚ";
		int[] vocal = { 0, 0, 0, 0, 0 };
		int pos = 0;
		for (String lista : entrada) { // Recorremos la lista de elementos
			for (char letra : lista.toCharArray()) { // Buscamos todos los caracteres
				for (char lector : VOCALES.toCharArray()) { // Buscamos su homónimo en nuestra lista de vocales
					if (letra == lector) {
						vocal[(pos % 5)]++; // Aumentamos la posición adscrita a la vocal. Debido al órden de la lista
											// de vocales (de 5 en 5, se repiten las mismas vocales) nos permite
											// establecer la misma vocal pero con distintas características en la misma
											// posición en la lista final que guarda las vocales
					}
					pos++; // Una vez acabamos con una vocal, pasamos a la siguiente
				}
			}
		}
		for (int i = 0; i < 5; i++) {
			System.out.println("La vocal " + VOCALES.toCharArray()[i] + " aparece " + vocal[i] + " veces"); // Leemos nuestra vocal
		}
	}

	private static void reversor(ArrayList<String> entrada) {
		Collections.reverse(entrada); // Revertimos el orden de los arrays. CUIDADO QUE CAMBIA LA LISTA ORIGINAL
		System.out.print("La frase invertida es: ");
		for (int i = 0; i < entrada.size(); i++) {
			for (int j = entrada.get(i).length() - 1; j >= 0; j--) { // Recorremos cada array del revés
				System.out.print(entrada.get(i).charAt(j));
			}
			System.out.print(" "); // Separamos los diferentes elementos de la lista por espacios
		}
		Collections.reverse(entrada); // Collections afecta a lista, por lo que hay que re-invertirlo
	}

	private static void sustituyE(ArrayList<String> entrada) {
		System.out.print("\nSustituyendo todas las vocales por la vocal e, el texto queda así: ");
		for (String aux : entrada) {
			aux = aux.replace("a", "e");
			aux = aux.replace("i", "e");
			aux = aux.replace("o", "e");
			aux = aux.replace("u", "e");
			aux = aux.replace("á", "é");
			aux = aux.replace("í", "é");
			aux = aux.replace("ó", "é");
			aux = aux.replace("ú", "é");
			aux = aux.replace("A", "E");
			aux = aux.replace("I", "E");
			aux = aux.replace("O", "E");
			aux = aux.replace("U", "E");
			aux = aux.replace("Á", "É");
			aux = aux.replace("Í", "É");
			aux = aux.replace("Ó", "É");
			aux = aux.replace("Ú", "É");
			System.out.print(aux + " ");
		}
	}
	/*
	 * final String VOCALES = "aAáÁiIíÍoOóÓuUúÚ"; int pos = 0; for (int i = 0; i <
	 * entrada.size(); i++) { for (int j = 0; j < entrada.get(i).length(); j++) {
	 * for (int k = 0; k < VOCALES.length(); k++) { char aux =
	 * entrada.get(i).charAt(j); if (VOCALES.charAt(k) == aux) { switch
	 * (VOCALES.indexOf(pos % 4)) { case 0: aux = 'e'; break; case 1: aux = 'E';
	 * break; case 2: aux = 'é'; break; case 3: aux = 'É'; break; } pos++; } } } }
	 * for (String aux : entrada) { System.out.print(aux + " "); }
	 */

	private static void contadorCaracteres(ArrayList<String> entrada) {
		int contador = 0;
		for (String aux : entrada) {
			contador = contador + aux.length();
		}
		if (contador != 1) {
			System.out.println("\nEn el texto hay " + contador + " caracteres");
		} else {
			System.out.println("\nEn el texto hay " + contador + " caracter");
		}
	}

	private static void contadorNumeros(ArrayList<String> entrada) {
		final String NUMEROS = "0123456789";
		int contador = 0;
		for (char lector : NUMEROS.toCharArray()) {
			for (String lista : entrada) {
				for (char letra : lista.toCharArray()) {
					if (letra == lector) {
						contador++;
					}
				}
			}
		}
		if (contador != 1) {
			System.out.println("De todos esos caracteres, hay " + contador + " números");
		} else {
			System.out.println("De todos esos caracteres, hay " + contador + " número");
		}
	}
}
