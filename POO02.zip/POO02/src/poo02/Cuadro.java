package poo02;

public class Cuadro {

	private String nombre = "Nombre de Ejemplo";
	private String autor = "Autor de Ejemplo";
	private int fecha = 0;
	private String estilo = "Estilo de ejemplo";
	private String info = "Información de ejemplo";
	private String foto = "Fotografía de ejemplo";
	private String descripcion = "Estilo de ejemplo";
	private boolean restaurado = false;
	private double alto = 0;
	private double ancho = 0;

	public Cuadro(String nombre, String autor, int fecha) {
		this.nombre = nombre;
		this.autor = autor;
		this.fecha = fecha;
	}


	public Cuadro() {

	}
	
	public String getAutor() {return autor;}//Getter
	public void setAutor(String autor) {this.autor = autor;}//Setter

	public String getInfo() {return info;}//Getter
	public void setInfo(String info) {this.info = info;}//Setter

	public String getFoto() {return foto;}//Getter
	public void setFoto(String foto) {this.foto = foto;}//Setter

	public String getDescripcion() {return descripcion;}//Getter
	public void setDescripcion(String descripcion) {this.descripcion = descripcion;}//Setter

	public boolean isRestaurado() {return restaurado;}//Getter
	public void setRestaurado(boolean restaurado) {this.restaurado = restaurado;}//Setter

	public String getNombre() {return nombre;}//Getter
	public void setNombre(String nombre) {this.nombre = nombre;}//Setter

	public int getFecha() {return fecha;}//Getter
	public void setFecha(int fecha) {this.fecha = fecha;}//Setter

	public String getEstilo() {return estilo;}//Getter
	public void setEstilo(String estilo) {this.estilo = estilo;}
	
	public double getAlto() {return alto;}//Getter
	public void setAlto(double alto) {this.alto = alto;}//Setter
	
	public double getAncho() {return ancho;}//Getter
	public void setAncho(double ancho) {this.ancho = ancho;}//Setter
	
	
	public double calcularDimensiones() { //te lo da en pulgadas
		double x = Math.round(Math.sqrt((Math.pow(getAlto(), 2)+ Math.pow(getAncho(), 2))) * 0.39);
		return x;
	}
}
