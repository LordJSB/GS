package poo02;

import java.util.*;

public class Museo {

	private String ubicacion = "sitio de ejemplo";
	private String dueño = "propietario de ejemplo";
	private String salas = "salas de ejemplo";
	private ArrayList<Empleado> listaEmpleados = new ArrayList<>();
	private String horario = "horario de ejemplo";
	private int cantidadObras = 0;
	private ArrayList<Cuadro> listaObras = new ArrayList<>();

	public Museo(String ubicacion, String dueño, String salas, ArrayList<Empleado> listaEmpleados, String horario, int cantidadObras,
			ArrayList<Cuadro> listaObras) {
		super();
		this.ubicacion = ubicacion;
		this.dueño = dueño;
		this.salas = salas;
		this.listaEmpleados = listaEmpleados;
		this.horario = horario;
		this.cantidadObras = cantidadObras;
		this.listaObras = listaObras;
	}

	public String getUbicacion() {return ubicacion;} //Getter
	public void setUbicacion(String ubicacion) {this.ubicacion = ubicacion;} //Setter

	public String getDueño() {return dueño;}//Getter
	public void setDueño(String dueño) {this.dueño = dueño;}//Setter

	public String getSalas() {return salas;}//Getter
	public void setSalas(String salas) {this.salas = salas;}//Setter

	public ArrayList<Empleado> getListaEmpleados() {return listaEmpleados;}//Getter
	public void setListaEmpleados(ArrayList<Empleado> listaEmpleados) {this.listaEmpleados = listaEmpleados;} //Setter
	
	public String getHorario() {return horario;}//Getter
	public void setHorario(String horario) {this.horario = horario;}//Setter

	public int getCantidadObras() {return cantidadObras;}//Getter
	public void setCantidadObras(int cantidadObras) {this.cantidadObras = cantidadObras;}//Setter

	public ArrayList<Cuadro> getListaObras() {return listaObras;}//Getter
	public void setListaObras(ArrayList<Cuadro> listaObras) {this.listaObras = listaObras;}//Setter
	
	public void getPintaEmpleados() {
		for (Empleado a : listaEmpleados) {
			System.out.println(a.getdni() + " " + a.getNombre() + " " + a.getApellidos() + " "+ a.getEdad() + " " + a.getPuesto());
		}
	}
	
	public void getPintaObras() {
		for (Cuadro a : listaObras) {
			System.out.println(a.getNombre() + " " + a.getAutor() + " " + a.getFecha());
		}
	}
	
	public void abrirMuseo() {}
	public void cerrarMuseo() {}
	public void aniadirEmpleado(String nombre, String apellido, String dni, int edad, String puesto){
		Empleado nuevoEmpleado = new Empleado(nombre,apellido,dni,edad,puesto);
		listaEmpleados.add(nuevoEmpleado);	
	} 
	public void eliminarEmpleado(String nombre){
//		
//		for(int i = 0; i < listaEmpleados.size(); i++) {
//			//Variable que compruebe si el campo "nombre" coincide con la variable "nombre"
//			if(listaEmpleados.contains()) {
//			listaEmpleados.remove(i);
//			}
//		}
	}
	public void eliminarListaEmpleados(){
		listaEmpleados.clear();
	} 
	public void abrirSala() {}
	public void cerrarSala() {}
	public void aniadirObra(){} //HAZ ESTO XD
	public void eliminarObra(){} //HAZ ESTO XD
	public void muestraListaObras() {}

}