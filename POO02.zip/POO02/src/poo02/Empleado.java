package poo02;

public class Empleado {

	private String nombre = "";
	private String apellidos = "";
	private String dni ="";
	private int edad = 0;
	private String puesto = "";

	
	public Empleado() {
		System.out.println("Empleado creado");
	}
	
	
	public Empleado(String nombre, String apellidos, String dni, int edad, String puesto) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
		this.edad = edad;
		this.puesto = puesto;
	}

	public String getNombre() {return nombre;}//Getter
	public void setNombre(String nombre) {this.nombre = nombre;}//Setter

	public String getApellidos() {return apellidos;}//Getter
	public void setApellidos(String apellidos) {this.apellidos = apellidos;}//Setter

	public String getdni() {return dni;}//Getter
	public void setdni(String dni) {this.dni = dni;}//Setter

	public int getEdad() {return edad;}//Getter
	public void setEdad(int edad) {this.edad = edad;}//Setter

	public String getPuesto() {return puesto;}//Getter
	public void setPuesto(String puesto) {this.puesto = puesto;}//Setter

}
