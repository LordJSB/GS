package poo02;

import java.util.*;

public class MainClass {

	public static void main(String[] args) {

		ArrayList<Empleado> listaEmpleados = new ArrayList<>();
		ArrayList<Cuadro> listaCuadros = new ArrayList<>();

		Empleado Juan = new Empleado("Juan", "Garnizo", "09080908A", 69, "estatua");
		Empleado Gerardo = new Empleado("Gerardo", "Mondongo", "11111111Z", 420, "porros");
		Empleado Narcisa = new Empleado("Narcisa", "Elvisa", "12345678B", 5, "transeunte");
		listaEmpleados.add(Juan);
		listaEmpleados.add(Gerardo);
		listaEmpleados.add(Narcisa);

		Cuadro cuadro1 = new Cuadro("La Gioconda", "Leonardo DaVinci", 1999);
		Cuadro cuadro2 = new Cuadro("Guernica", "Picasso", 1998);
		Cuadro cuadro3 = new Cuadro("Meninas", "Velázquez", 2021);
		listaCuadros.add(cuadro1);
		listaCuadros.add(cuadro2);
		listaCuadros.add(cuadro3);

		Museo prado = new Museo("Madrid", "ESPAÑA", "Sala de cuadros", listaEmpleados, "00:00 - 13:59", 5,
				listaCuadros);
		System.out.println("En el museo hay estos empleados: ");
		prado.getPintaEmpleados();
		System.out.println("\nEn el museo hay estos cuadros: ");
		prado.getPintaObras();
		
		prado.aniadirEmpleado("Gertrudis","Garcia", "09876543Z", 87, "enterrador");
		System.out.println("\nEn el museo hay estos empleados: ");
		prado.getPintaEmpleados();
		
		System.out.println("\nEl Museo del Prado está en " + prado.getUbicacion());
		System.out.println("Los cuadros del Museo del Prado está en la " + prado.getSalas());
		System.out.println("La lista de empleados del Museo del Prado es " + prado.getListaEmpleados()); // NESESITO
																											// BUCLE
																											// PARA LEER
																											// TODA LA
																											// LISTA XD
		System.out.println("El horario del Museo del Prado es " + prado.getHorario());
		System.out.println("El Museo del Prado contiene " + prado.getCantidadObras() + " obras");
		System.out.println("El Museo del Prado contiene los siguientes cuadros al público: " + prado.getListaObras()); // NESESITO
																														// BUCLE
																														// PARA
																														// LEER
																														// TODA
																														// LA
																														// LISTA
																														// XD
	}
}
