/**
 * 
 */
/**
 * @author julio.semper
 *
 */
module POO02 {
}