module POO_Deluxe {
	requires java.desktop;
}