package poo_Deluxe;

import javax.swing.JOptionPane;

public class POO_Deluxe {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Bienvenido al museo" + "Del prado");

		int dialogoPorPantalla = JOptionPane.showConfirmDialog(null, "EStás seguro de querer entrar en el museo",
				"Warning", JOptionPane.YES_NO_OPTION);
		
		if(dialogoPorPantalla == JOptionPane.YES_OPTION) {
			System.out.println("Ha dicho que si");
		}else {
			System.out.println("Sigue buscando");
		}
	}
}
