package p11_SemperBarcena_Julio;


import java.util.ArrayList;

/**
 * @author julio.semper
 *
 */
public class Empleado {

	private String nombre;
	private String apellidos;
	private int sueldoBruto;
	private int antiguedad;
	private int hijos;
	private String categoria;
	private ArrayList<Material> equipamiento = new ArrayList<>();
	private int irpf;
	private int bonus;
	private int sueldoNeto;

	/**
	 * Constructor predeterminado para empleados con los datos mínimos
	 * 
	 * @param nombre      nombre del empleado
	 * @param apellidos   apellidos del empleado
	 * @param sueldoBruto sueldo bruto del empleado
	 * 
	 */
	public Empleado(String nombre, String apellidos, int sueldoBruto) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.sueldoBruto = sueldoBruto;
		antiguedad = 0;
		hijos = 0;
		categoria = "junior";
		equipamiento = setEquipamiento(this.categoria);
		irpf = setIRPF(this.sueldoBruto);
		bonus = 5;
		sueldoNeto = setSueldoNeto(this.sueldoBruto, this.irpf, this.bonus, cuentaBonus(this.antiguedad, this.hijos));
	}

	/**
	 * Constructor completo
	 * 
	 * @param nombre      nombre del empleado
	 * @param apellidos   apellidos del empleado
	 * @param sueldoBruto sueldo bruto del empleado
	 * @param antiguedad  Años de veteranía en la empresa
	 * @param hijos       Número de hijos que tiene el empleado
	 * @param categoria   Tipo de empleado en la empresa. Dependiendo de la
	 *                    categoría, se establecen unos bonus y materiales
	 *                    predeterminados
	 * 
	 */
	public Empleado(String nombre, String apellidos, int sueldoBruto, int antiguedad, int hijos, String categoria) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.sueldoBruto = sueldoBruto;
		this.antiguedad = antiguedad;
		this.hijos = hijos;
		this.categoria = categoria;
		equipamiento = setEquipamiento(this.categoria);
		irpf = setIRPF(this.sueldoBruto);
		bonus = setBonus(this.categoria);
		sueldoNeto = setSueldoNeto(this.sueldoBruto, this.irpf, this.bonus, cuentaBonus(this.antiguedad, this.hijos));
	}

	/**
	 * Función Get del atributo nombre. Devuelve el nombre del empleado
	 * 
	 * @return nombre nombre del objeto empleado en cuestión
	 * 
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Función Set del atributo nombre. Establece un String como el nombre del
	 * empleado
	 * 
	 * @param nombre nombre del empleado a asignar
	 * 
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Función Get del atributo apellidos. Devuelve los apellidos del empleado
	 * 
	 * @return apellidos apellidos del objeto empleado en cuestión
	 * 
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * Función Set del atributo apellidos. Establece un String como los apellidos
	 * del empleado
	 * 
	 * @param apellidos apellidos del empleado a asignar
	 * 
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * Función Get del atributo sueldoBruto. Devuelve el sueldo bruto del empleado
	 * 
	 * @return sueldoBruto salario emitido por AENA del empleado en cuestión
	 * 
	 */
	public int getSueldoBruto() {
		return sueldoBruto;
	}

	/**
	 * Función Set del atributo sueldoBruto. Establece un numero entero como el
	 * salario bruto del empleado
	 * 
	 * @param sueldoBruto salario en bruto del empleado a asignar
	 * 
	 */
	public void setSueldoBruto(int sueldoBruto) {
		this.sueldoBruto = sueldoBruto;
	}

	/**
	 * Función Get del atributo antiguedad. Devuelve los años de antiguedad del
	 * empleado
	 * 
	 * @return antiguedad años de veteranía en AENA del empleado en cuestión
	 * 
	 */
	public int getAntiguedad() {
		return antiguedad;
	}

	/**
	 * Función Set del atributo antiguedad. Establece un numero entero como los años
	 * de antiguedad del empleado
	 * 
	 * @param antiguedad años de antiguedad del empleado a asignar
	 * 
	 */
	public void setAntiguedad(int antiguedad) {
		this.antiguedad = antiguedad;
	}

	/**
	 * Función Get del atributo hijos. Devuelve el número de hijos del empleado
	 * 
	 * @return hijos número de hijos del empleado en cuestión
	 * 
	 */
	public int getHijos() {
		return hijos;
	}

	/**
	 * Función Set del atributo hijos. Establece un numero entero como el número de
	 * hijos del empleado
	 * 
	 * @param hijos número de hijos del empleado a asignar
	 * 
	 */
	public void setHijos(int hijos) {
		this.hijos = hijos;
	}

	/**
	 * Función Get del atributo categoria. Devuelve el puesto del empleado
	 * 
	 * @return categoria nombre del puesto del empleado en cuestión
	 * 
	 */
	public String getCategoria() {
		return categoria;
	}

	/**
	 * Función Set del atributo categoria. Establece una cadena String como el
	 * puesto del empleado
	 * 
	 * @param categoria Tipo de puesto del empleado a asignar
	 * 
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	/**
	 * Función Get del atributo equipamiento. Devuelve la lista de objetos Material
	 * adsritos a este trabajador
	 * 
	 * @return equipamiento lista de materiales del empleado actual
	 * 
	 */
	public ArrayList<Material> getEquipamiento() {
		return equipamiento;
	}

	/**
	 * Función encargada de asignar una cantidad determinada de material empresarial
	 * según la categoría del empleado.
	 * 
	 * @param categoria Tipo de puesto del empleado cuyo material va a ser asignado
	 * 
	 * @return equipo cantidad total de bonuses recibidos por el empleado según
	 *         criterios de la empresa
	 */
	public ArrayList<Material> setEquipamiento(String categoria) {
		ArrayList<Material> equipo = new ArrayList<>();
		switch (categoria) {
		case "junior":
			equipo.add(new Material("portatil", 1));
			break;
		case "senior":
			equipo.add(new Material("portatil", 2));
			break;
		case "manager":
			equipo.add(new Material("portatil", 3));
			equipo.add(new Material("telefono", 1));
			equipo.add(new Material("coche", 1));
			break;
		case "Arquitecto":
			equipo.add(new Material("portatil", 4));
			equipo.add(new Material("telefono", 2));
			equipo.add(new Material("coche", 2));
			break;
		}
		return equipo;
	}

	/**
	 * Función Get del atributo irpf. Devuelve el porcentaje de irpf a descontar del
	 * empleado.
	 * 
	 * @return irpf numero entero que representa el porcentaje del irpf a descontar
	 *         del empleado actual sobre su sueldo bruto y bonos
	 * 
	 */
	public int getIrpf() {
		return irpf;
	}

	/**
	 * Función Set del atributo irpf. Establece un numero entero como porcentaje a
	 * descontar del conjunto del sueldo bruto y los bonuses porcentuales e
	 * individuales por antiguedad e hijos. Se establece un límite del 50% de IRPF a
	 * los sueldos más altos (Que te vote Txapote)
	 * 
	 * @param sueldoBruto numero entero que representa el sueldo bruto del
	 *                    trabajador actual
	 * 
	 */
	public int setIRPF(int sueldoBruto) {
		int irpf = 10;
		int aux = sueldoBruto;
		if (aux > 15000) {
			aux -= 15000;
			for (int i = 5000; aux / i > 0; i += 5000) {
				irpf += 2;
				if (irpf >= 50) {
					break;
				}
			}
		}
		return irpf;
	}

	public int getBonus() {
		return bonus;
	}

	/**
	 * Función Set del atributo bonus. Establece el porcentaje de bonificación
	 * adicional de su sueldo bruto según su categoria, estandarizado por la empresa
	 * 
	 * @param categoria Tipo de puesto del empleado actual
	 * 
	 * @return bonus Porcentaje, representado con números enteros, correspondiente
	 *         al trabajador actual según su categoria
	 */
	public int setBonus(String categoria) {
		int bonus = 5;
		switch (categoria.toLowerCase()) {
		case "junior":
			break;
		case "senior":
			bonus = 10;
			break;
		case "manager":
			bonus = 12;
			break;
		case "arquitecto":
			bonus = 25;
			break;
		default:
			System.out.println("ERROR: se ha insertado una categoría de empleado no válida");
			break;
		}
		return bonus;
	}

	/**
	 * Función Get del atributo sueldoNeto. Devuelve el sueldo neto del empleado
	 * actual
	 * 
	 * @return sueldoNeto cantidad equivalente al sueldo neto del trabajador en
	 *         cuestión
	 * 
	 */
	public int getSueldoNeto() {
		return sueldoNeto;
	}

	/**
	 * Función Set del atributo sueldoNeto. Este sueldo será calculado
	 * automáticamente mediante una fórmula, la cual aplica tanto los bonuses
	 * porcentuales de la empresa como los bonus adicionales por antiguedad y por
	 * número de hijos. Tanto los bonuses como el sueldo se calculan anualmente
	 * 
	 * @param sueldoBruto Sueldo bruto del empleado representado como un numero
	 *                    entero
	 * @param irpf        Porcentaje del sueldo a sustraer por impuestos. Se
	 *                    representa como un número entero
	 * @param bonus       Porcentaje de sueldo adicional asignado según la categoría
	 *                    del empleado. Se representa como un número entero
	 * @param bonuses     Beneficios planos por criterios de la empresa.
	 *                    Representados como un número entero
	 * 
	 */
	public int setSueldoNeto(int sueldoBruto, int irpf, int bonus, int bonuses) {
		int sueldoNeto = ((((sueldoBruto * (100 + bonus) / 100) + bonuses) * (100 - irpf)) / 100);
		return sueldoNeto;
	}

	/**
	 * Función encargada de la contabilización de bonuses adicionales por años de
	 * antiguedad y cantidad de hijos del empleado Para ver los parámetros
	 * predeterminados, diríjase al constructor
	 * {@link #Empleado(String nombre, String apellidos, int sueldoBruto) Empleado}
	 * predeterminado
	 * 
	 * @param antiguedad Años de veteranía del empleado a tener en cuenta
	 * @param hijos      Cantidad de hijos del empleado a tener en cuenta
	 * 
	 * @return b cantidad total de bonuses recibidos por el empleado según criterios
	 *         de la empresa
	 */
	public int cuentaBonus(int antiguedad, int hijos) {
		int a = 0, h = 0, b;
		for (int i = 0; hijos > i; i++) {
			h += 120;
		}
		for (int j = 0; antiguedad > j; j++) {
			a += 240;
		}
		b = a + h;
		return b;
	}

	/**
	 * Función encargada de eliminar el equipamiento del empleado que no exista en
	 * stock, usado en {@link Main#compruebaStock(Stock, Plantilla)} para comprobar
	 * si existe dicho equipamiento en el stock de la empresa
	 * 
	 * @param e        Empleado en concreto a sustraer el equipamiento faltante
	 * @param faltante material que no se encuentra en stock actualmente
	 */
	public void vaciaMaterial(Empleado e, Material faltante) {
		e.equipamiento.remove(faltante);
	}
}
