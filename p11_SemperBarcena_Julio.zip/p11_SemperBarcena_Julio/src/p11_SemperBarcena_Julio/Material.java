package p11_SemperBarcena_Julio;


/**
 * @author julio.semper
 *
 */
public class Material {
	private String nombre;
	private int categoria;
	private int coste;
	private boolean enUso;

	/**
	 * Constructor de los objetos Material
	 * 
	 * @param nombre    cadena de caracteres que indica el
	 * @param categoria Tipo de puesto del empleado cuyo material va a ser asignado
	 * 
	 */
	public Material(String nombre, int categoria) {
		this.nombre = nombre;
		this.categoria = categoria;
		coste = setCoste(nombre, categoria);
		this.enUso = false;
	}

	/**
	 * Función encargada de devolver el nombre del material en cuestion
	 * 
	 * @return nombre tipo de material actual
	 * 
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Función encargada de establecer el nombre de un material
	 * 
	 * @param nombre tipo de material a designar al empleado
	 * 
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Función encargada de devolver el nivel de categoria del material en cuestion
	 * 
	 * @return categoria nivel de calidad del material actual
	 * 
	 */
	public int getCategoria() {
		return categoria;
	}

	/**
	 * Función encargada de asignar el nivel de calidad del material actual
	 * 
	 * @param categoria nivel de calidad del material en concreto
	 * 
	 */
	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	/**
	 * Función encargada de devolver el coste anual del material actual
	 * 
	 * @return coste equivalente al gasto anual de la empresa por este material
	 *         concreto
	 */
	public int getCoste() {
		return coste;
	}

	/**
	 * Función encargada de asignar el coste anual del material según su nombre y
	 * categoría
	 * 
	 * @param nombre    tipo de material a designar al empleado
	 * @param categoria nivel de calidad del material en concreto
	 * 
	 * @return coste cantidad total de bonuses recibidos por el empleado según
	 */
	public int setCoste(String nombre, int categoria) {
		int coste = 0;
		if (nombre.equalsIgnoreCase("portatil")) {
			switch (categoria) {
			case 1:
				coste = 500;
				break;
			case 2:
				coste = 800;
				break;
			case 3:
				coste = 1000;
				break;
			case 4:
				coste = 2000;
				break;
			default:
				System.out.println("ERROR: categoría de portátil no válida");
				break;
			}
		} else if (nombre.equalsIgnoreCase("telefono")) {
			switch (categoria) {
			case 1:
				coste = 300;
				break;
			case 2:
				coste = 1000;
				break;
			default:
				System.out.println("ERROR: categoría de teléfono no válida");
				break;
			}
		} else if (nombre.equalsIgnoreCase("coche")) {
			switch (categoria) {
			case 1:
				coste = 23000;
				break;
			case 2:
				coste = 52000;
				break;
			default:
				System.out.println("ERROR: categoría de coche no válida");
				break;
			}
		}
		return coste;
	}

	/**
	 * Función encargada de revelar si el material actual está en stock o no
	 * 
	 * @return enUso Si se encuentra en falso, este material no esta en uso. En caso
	 *         contrario, estaria en uso
	 */
	public boolean getEnUso() {
		return enUso;
	}

	/**
	 * Función encargada de establecer la disponibilidad del material actual
	 * 
	 * @param enUso Si se encuentra en falso, este material no esta en uso. En caso
	 *              contrario, estaria en uso
	 * 
	 */
	public void setEnUso(boolean enUso) {
		this.enUso = enUso;
	}
}