package p8_SemperBarcena_Julio;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author julio.semper
 *
 * 
 */
public class Plantilla {
	ArrayList<Empleado> plantilla = new ArrayList<>();

	/**
	 * Constructor predeterminado para la totalidad de empleados de la empresa
	 * 
	 */
	public Plantilla() {
		plantilla = setPlantilla();
	}

	/**
	 * Función encargada de devolver la plantilla de trabajadores actuales
	 * 
	 * @return plantilla lista de empleados establecidos por el usuario en
	 *         {@link Plantilla#setPlantilla()}
	 * 
	 */
	public ArrayList<Empleado> getPlantilla() {
		return plantilla;
	}

	/**
	 * Función encargada de crear una lista de empleados según el input del usuario
	 * 
	 * @return plantilla lista de objetos Empleado donde consta todos los empleados
	 *         de la empresa
	 * 
	 */
	public ArrayList<Empleado> setPlantilla() {
		@SuppressWarnings("resource")
		Scanner teclado = new Scanner(System.in).useDelimiter("\r\n");
		ArrayList<Empleado> plantilla = new ArrayList<>();
		boolean bucle = true;
		do {
			System.out.print("Inserte el nombre de un empleado: ");
			String nombre = teclado.next();
			System.out.print("Inserte los apellidos del empleado " + nombre + ": ");
			String apellidos = teclado.next();
			int sueldoBruto = compruebaNumeros(teclado,
					"Inserte el sueldo bruto del empleado " + nombre + " " + apellidos + ": ");
			System.out.print(
					"¿Va a insertar más datos sobre el empleado? En caso contrario, se establecerán los estándares de la empresa;"
							+ "\n\u2580 Su categoría será 'Junior'"
							+ "\n\u2580 No tendrá ni hijos ni años de antigüedad asignados"
							+ "\nEscriba su respuesta con un SI o un NO: ");
			if (teclado.next().equalsIgnoreCase("si")) {
				int antiguedad = compruebaNumeros(teclado,
						"Inserte los años de antigüedad del empleado " + nombre + ": ");
				int hijos = compruebaNumeros(teclado,
						"Inserte el numero de hijos del empleado " + nombre + " " + apellidos + ": ");
				String categoria = compruebaCategoria(teclado,
						"Inserte la categoría del empleado " + nombre + " " + apellidos + ": ");
				plantilla.add(new Empleado(nombre, apellidos, sueldoBruto, antiguedad, hijos, categoria));
			} else {
				plantilla.add(new Empleado(nombre, apellidos, sueldoBruto));
			}
			System.out.print("¿Desea insertar un nuevo empleado? Responda con un SI o un NO: ");
			if (teclado.next().equalsIgnoreCase("si")) {
				System.out.println("Creando perfil de empleado...\nListo.\nCreando nuevo perfil...");
			} else {
				System.out.println("Ajustando los detalles finales...\n...\n...\n...OK");
				bucle = false;
			}
		} while (bucle);
		return plantilla;
	}

	/**
	 * Función encargada de comprobar que el contenido transmitido por teclado es un
	 * numero. Usado en {@link Plantilla#setPlantilla()}
	 * 
	 * @return x numero final
	 * 
	 */
	@SuppressWarnings("resource")
	public int compruebaNumeros(Scanner sc, String algo) {
		int x = 0;
		boolean seguir = false;
		do {
			sc = new Scanner(System.in);
			System.out.print(algo);
			if (sc.hasNextInt()) {
				x = sc.nextInt();
				seguir = true;
			} else {
				System.out.println("ERROR: introduce un entero");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}

	/**
	 * Función encargada de comprobar que el contenido transmitido por teclado es
	 * una categoria de empleado. Usado en {@link Plantilla#setPlantilla()}
	 * 
	 * @return x categoria de empleado valida
	 * 
	 */
	@SuppressWarnings("resource")
	public String compruebaCategoria(Scanner sc, String algo) {
		String x = "";
		boolean seguir = false;
		do {
			sc = new Scanner(System.in).useDelimiter("\r\n");
			System.out.print(algo);
			String aux = sc.next();
			if (aux.equalsIgnoreCase("junior") || aux.equalsIgnoreCase("senior") || aux.equalsIgnoreCase("manager")
					|| aux.equalsIgnoreCase("arquitecto")) {
				x = aux;
				seguir = true;
			} else {
				System.out.println(
						"ERROR: En AENA, sólo existen las siguientes categorías: 'Junior', 'Senior', 'Manager' y 'Arquitecto'");
				seguir = false;
			}
		} while (seguir == false);
		return x;
	}
}
//
//public ArrayList<Empleado> setPlantilla() {
//    ArrayList<Empleado> plantilla = new ArrayList<>();
//    boolean bucle = true;
//    do {
//        plantilla.add(createEmpleado());
//        System.out.print("¿Desea insertar un nuevo empleado? Responda con un SI o un NO: ");
//        if (new Scanner(System.in).next().equalsIgnoreCase("si")) {
//            System.out.println("Creando perfil de empleado...\nListo.\nCreando nuevo perfil...");
//        } else {
//            System.out.println("Ajustando los detalles finales...\n...\n...\n...OK");
//            bucle = false;
//        }
//    } while (bucle);
//    return plantilla;
//}
//
///**
// * Función encargada de crear un objeto Empleado según el input del usuario
// *
// * @return empleado objeto Empleado creado
// *
// */
//private Empleado createEmpleado() {
//    Scanner teclado = new Scanner(System.in).useDelimiter("\r\n");
//    System.out.print("Inserte el nombre de un empleado: ");
//    String nombre = teclado.next();
//    System.out.print("Inserte los apellidos del empleado " + nombre + ": ");
//    String apellidos = teclado.next();
//    int sueldoBruto = compruebaNumeros(teclado,
//            "Inserte el sueldo bruto del empleado " + nombre + " " + apellidos + ": ");
//    System.out.print(
//            "¿Va a insertar más datos sobre el empleado? En caso contrario, se establecerán los estándares de la empresa;"
//                    + "\n\u2580 Su categoría será 'Junior'"
//                    + "\n\u2580 No tendrá ni hijos ni años de antigüedad asignados"
//                    + "\nEscriba su respuesta con un SI o un NO: ");
//    if (teclado.next().equalsIgnoreCase("si")) {
//        int antiguedad = compruebaNumeros(teclado,
//                "Inserte los años de antigüedad del empleado " + nombre + ": ");
//        int hijos = compruebaNumeros(teclado,
//                "Inserte el numero de hijos del empleado " + nombre + " " + apellidos + ": ");
//        String categoria = compruebaCategoria(teclado,
//                "Inserte la categoría del empleado " + nombre + " " + apellidos + ": ");
//        return new Empleado(nombre, apellidos, sueldoBruto, antiguedad, hijos, categoria);
//    } else {
//        return new Empleado(nombre, apellidos, sueldoBruto);
//    }
//}
//public ArrayList<Empleado> createEmpleadoFromFile(String filename) {
//    ArrayList<Empleado> empleados = new ArrayList<>();
//
//    try (Scanner scanner = new Scanner(new File(filename))) {
//        while (scanner.hasNextLine()) {
//            String line = scanner.nextLine();
//            String[] fields = line.split(",");
//            String nombre = fields[0].trim();
//            String apellidos = fields[1].trim();
//            int sueldoBruto = Integer.parseInt(fields[2].trim());
//            int antiguedad = Integer.parseInt(fields[3].trim());
//            int hijos = Integer.parseInt(fields[4].trim());
//            String categoria = fields[5].trim();
//
//            empleados.add(new Empleado(nombre, apellidos, sueldoBruto, antiguedad, hijos, categoria));
//        }
//    } catch (FileNotFoundException e) {
//        System.err.println("Error: " + filename + " not found.");
//    } catch (NumberFormatException e) {
//        System.err.println("Error: invalid number format in file " + filename + ".");
//    } catch (Exception e) {
//        System.err.println("Error: " + e.getMessage());
//    }
//
//    return empleados;
//}
//public ArrayList<Empleado> loadPlantillaFromFile(String filename) throws FileNotFoundException {
//    ArrayList<Empleado> plantilla = new ArrayList<>();
//    File file = new File(filename);
//    Scanner scanner = new Scanner(file);
//    while (scanner.hasNextLine()) {
//        String line = scanner.nextLine();
//        String[] parts = line.split(",");
//        if (parts.length != 4 && parts.length != 6) {
//            System.err.println("Error: invalid data format in line " + line);
//            continue;
//        }
//        String nombre = parts[0];
//        String apellidos = parts[1];
//        int sueldoBruto = Integer.parseInt(parts[2]);
//        if (parts.length == 4) {
//            plantilla.add(new Empleado(nombre, apellidos, sueldoBruto));
//        } else {
//            int antiguedad = Integer.parseInt(parts[3]);
//            int hijos = Integer.parseInt(parts[4]);
//            String categoria = parts[5];
//            plantilla.add(new Empleado(nombre, apellidos, sueldoBruto, antiguedad, hijos, categoria));
//        }
//    }
//    scanner.close();
//    return plantilla;
//}

