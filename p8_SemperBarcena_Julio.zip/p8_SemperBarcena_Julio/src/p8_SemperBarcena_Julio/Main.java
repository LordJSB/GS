/**
 * 
 */
package p8_SemperBarcena_Julio;

import java.util.ArrayList;
import java.text.DecimalFormat;

/**
 * @author julio.semper
 *
 */
public class Main {

	/**
	 * Función principal del programa
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Stock almacen = new Stock();
		System.out.println("Bienvenido al departamento comercial de AENA [sin h :) ] ");
		Plantilla empleadosAena = new Plantilla();
		empleadosAena = compruebaStock(almacen, empleadosAena);
		cuentaEmpleados(empleadosAena);
		calculaMediaHijos(empleadosAena);
		empleadoMasAsalariado(empleadosAena);
		sueldoNetoMedio(empleadosAena);
		listadoCoches(empleadosAena);
		calculaCostesEmpresa(empleadosAena);
	}

	/**
	 * Función encargada del recuento de empleados según su categoria
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()} por el usuario
	 * 
	 */
	public static void cuentaEmpleados(Plantilla empleadosAena) {
		int cJ = 0, // Contador que registra el número de juniors de la empresa
				cS = 0, // Contador que registra el número de seniors de la empresa
				cM = 0, // Contador que registra el número de managers de la empresa
				cA = 0; // Contador que registra el número de arquitectos de la empresa
		for (Empleado e : empleadosAena.getPlantilla()) {
			switch (e.getCategoria().toLowerCase()) {
			case "junior":
				cJ++;
				break;
			case "senior":
				cS++;
				break;
			case "manager":
				cM++;
				break;
			case "arquitecto":
				cA++;
				break;
			}
		}
		System.out.println("De entre toda la plantilla, se listarán según su categoría: ");
		System.out.println("Número de trabajadores Juniors: " + cJ);
		System.out.println("Número de trabajadores Seniors: " + cS);
		System.out.println("Número de trabajadores Managers: " + cM);
		System.out.println("Número de trabajadores Arquitectos: " + cA);
	}

	/**
	 * Función encargada de calcular la media de hijos de toda la plantilla
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()} por el usuario
	 * 
	 */
	public static void calculaMediaHijos(Plantilla empleadosAena) {
		float media = 0;
		int total = 0, hijos = 0;
		for (Empleado e : empleadosAena.getPlantilla()) {
			hijos += e.getHijos();
			if (e.getHijos() != 0) {
				total++;
			}
		}
		if (total == 0) {
			System.out.println("");
		} else {
			media = hijos / total;
		}
		System.out.println("El total de hijos de la empresa es de " + hijos + " hijos, ajustándose a unos "
				+ Math.floor(media) + " hijos por empleado");
	}

	/**
	 * Función encargada de encontrar el sueldo neto más alto de toda la plantilla
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()} por el usuario
	 * 
	 */
	public static void empleadoMasAsalariado(Plantilla empleadosAena) {
		int maxSueldoNeto = 0, maxSueldoBruto = 0;
		String nombreMaxNeto = "", nombreMaxBruto = "";
		for (Empleado e : empleadosAena.getPlantilla()) {
			if (e.getSueldoNeto() > maxSueldoNeto) {
				maxSueldoNeto = e.getSueldoNeto();
				nombreMaxNeto = e.getNombre() + " " + e.getApellidos();
			}
			if (e.getSueldoBruto() > maxSueldoBruto) {
				maxSueldoBruto = e.getSueldoBruto();
				nombreMaxBruto = e.getNombre() + " " + e.getApellidos();
			}
		}
		System.out.println("El sueldo neto más alto de toda la plantilla pertenece a " + nombreMaxNeto
				+ " con un sueldo de " + maxSueldoNeto);
		System.out.println("El sueldo bruto más alto de toda la plantilla pertenece a " + nombreMaxBruto
				+ " con un sueldo de " + maxSueldoBruto);
	}

	/**
	 * Función encargada de calcular la media de sueldo neto de la empresa
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()}
	 * 
	 */
	public static void sueldoNetoMedio(Plantilla empleadosAena) {
		DecimalFormat df = new DecimalFormat("####.##");
		double media = 0;
		int total = 0, sueldo = 0;
		for (Empleado e : empleadosAena.getPlantilla()) {
			sueldo += e.getSueldoNeto();
			total++;
		}
		media = sueldo / total;
		System.out.println(
				"La media de los sueldos netos de toda la plantilla es de " + df.format(media) + "\u20AC anuales");
	}

	/**
	 * Función encargada de listar los propietarios de los coches de la empresa
	 * 
	 * @param empleadosAena Version alterada de la plantilla teniendo en cuenta el
	 *                      stock disponible por parte de la empresa
	 *                      {@link #compruebaStock(Stock, Plantilla)}
	 * 
	 */
	public static void listadoCoches(Plantilla empleadosAena) {
		int coche1cont = 0, coche2cont = 0;
		ArrayList<String> propietariosC1 = new ArrayList<>();
		ArrayList<String> propietariosC2 = new ArrayList<>();
		for (Empleado e : empleadosAena.plantilla) {
			for (Material m : e.getEquipamiento()) {
				if (e.getCategoria().equalsIgnoreCase("manager") || e.getCategoria().equalsIgnoreCase("arquitecto")) {
					if (m.getNombre().equalsIgnoreCase("coche") && m.getCategoria() == 1) {
						coche1cont++;
						propietariosC1.add(e.getNombre());
					}
					if (m.getNombre().equalsIgnoreCase("coche") && m.getCategoria() == 2) {
						coche2cont++;
						propietariosC2.add(e.getNombre());
					}
				}
			}
		}
		if (coche1cont == 0 && coche2cont == 0) {
			System.out.println("En AENA, no se ha requerido de invertir en vehículos de empresa");
		} else {
			System.out.println("En AENA, se ha dispuesto de " + coche1cont + " coches de empresa a nuestros managers: "
					+ propietariosC1.toString());
			System.out.println("Asimismo, se han dispuesto de " + coche2cont
					+ " coches de empresa a nuestros arquitectos para su uso integro: " + propietariosC2.toString());
		}
	}

	/**
	 * Función encargada de calcular la inversion de capital de la empresa por medio
	 * de sus empleados y los materiales que disponen
	 * 
	 * @param empleadosAena instancia de objeto Plantilla; una lista de todos los
	 *                      empleados que componen a la empresa, creados a traves de
	 *                      {@link Plantilla#setPlantilla()}
	 * 
	 */
	public static void calculaCostesEmpresa(Plantilla empleadosAena) {
		int costesMaterial = 0, costeSueldo = 0;
		for (Empleado e : empleadosAena.plantilla) {
			for (Material m : e.getEquipamiento()) {
				costesMaterial += m.getCoste();
			}
			costeSueldo += e.getSueldoBruto();
		}
		System.out.println("La empresa ha invertido " + costeSueldo
				+ "\u20AC anuales en sueldos a sus empleados, mientras que invirtió " + costesMaterial
				+ "\u20AC anuales en materiales a sus empleados, dando un gasto total de "
				+ (costesMaterial + costeSueldo) + "\u20AC anuales");
	}

	/**
	 * Función encargada de comprobar la existencia de stock disponible para los
	 * empleados. En caso contrario, no se les asignará equipamiento
	 * 
	 * @param empleadosAena Version alterada de la plantilla teniendo en cuenta el
	 *                      stock disponible por parte de la empresa
	 *                      {@link #compruebaStock(Stock, Plantilla)}
	 * 
	 */
	public static Plantilla compruebaStock(Stock almacen, Plantilla empleadosAena) {
		Plantilla empleadosConMateriales = empleadosAena;
		for (Empleado e : empleadosAena.getPlantilla()) {
			for (Material ea : e.getEquipamiento()) {
				boolean asignado = false;
				for (Material a : almacen.getAlmacen()) {
					if (ea.getNombre().equalsIgnoreCase(a.getNombre()) && !(a.getEnUso() || ea.getEnUso())) {
						a.setEnUso(true);
						ea.setEnUso(true);
						asignado=true;
					}
				}
				if (!asignado) {
					e.vaciaMaterial(e, ea);
				}
			}
		}
		return empleadosConMateriales;
	}

}
