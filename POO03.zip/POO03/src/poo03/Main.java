package poo03;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<PilotoAvion> pilotoVuelo = new ArrayList<>();
		ArrayList<Avion> avionVuelo = new ArrayList<>();
		ArrayList<Pasajero> pasajerosVuelo = new ArrayList<>();

		ArrayList<String> licenciasJozeh = new ArrayList<>();
		ArrayList<String> tipoVuelosElpepe = new ArrayList<>();
		licenciasJozeh.add("gamer");
		licenciasJozeh.add("comercial");
		licenciasJozeh.add("militar");
		tipoVuelosElpepe.add("comercial");

		PilotoAvion Jozeh = new PilotoAvion("Jozeluíh", "García", "12345678Ñ", licenciasJozeh, "Iberia", 2000);
		pilotoVuelo.add(Jozeh);
		Avion ElPepe = new Avion("Boeing 777", "EU-CFL", 4, 500, tipoVuelosElpepe, 3000);
		avionVuelo.add(ElPepe);
		Pasajero Alfredo = new Pasajero("Alfredo", "Pérez Molina", "ABC1234567", 50);
		pasajerosVuelo.add(Alfredo);

		if (Jozeh.compruebaLicencias(Jozeh.getListaLicencias(), ElPepe.getTipoVuelos())) {
			Vuelo MadridAtocha = new Vuelo(pilotoVuelo, avionVuelo, "ABC1234567", "15:00", "16:00", "23:00",
					"Aeropuerto de Madrid", "Aeropuerto de Portugal");
			System.out.println("El vuelo Madrid-Atocha sale de " + MadridAtocha.getAeropuertoSalida());
			MadridAtocha.compruebaEmbarque(MadridAtocha, Alfredo);
			MadridAtocha.balance(ElPepe, pasajerosVuelo, Jozeh);
		} else {
			System.out.println("El piloto " + Jozeh.getNombre() + " y licencia " + Jozeh.getListaLicencias()
					+ " no puede pilotar el avión con matrícula " + ElPepe.getMatricula() + " y licencia "
					+ ElPepe.getTipoVuelos());
		}

	}

}
