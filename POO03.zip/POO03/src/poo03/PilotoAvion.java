package poo03;

import java.util.ArrayList;

public class PilotoAvion {

	private String nombre = "Nombre de Ejemplo";
	private String apellidos = "Apellidos de Ejemplo";
	private String dni = "00000000A";
	private ArrayList<String> listaLicencias = new ArrayList<>();
	private String aerolinea = "Aerolinea de Ejemplo";
	private int salario = 0;

	public PilotoAvion(String nombre, String apellidos, String dni, ArrayList<String> listaLicencias,
			String aerolinea, int salario) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
		this.listaLicencias = listaLicencias;
		this.aerolinea = aerolinea;
		this.salario = salario;
	}

	public String getNombre() {return nombre;}
	public void setNombre(String nombre) {this.nombre = nombre;}

	public String getApellidos() {return apellidos;}
	public void setApellidos(String apellidos) {this.apellidos = apellidos;}

	public String getDni() {return dni;}
	public void setDni(String dni) {this.dni = dni;}

	public ArrayList<String> getListaLicencias() {return listaLicencias;}
	public void setListaLicencias(ArrayList<String> listaLicencias) {this.listaLicencias = listaLicencias;}

	public String getAerolinea() {return aerolinea;}
	public void setAerolinea(String aerolinea) {this.aerolinea = aerolinea;}

	public int getSalario() {return salario;}
	public void setSalario(int salario) {this.salario = salario;}	
	
	public boolean compruebaLicencias(ArrayList<String> tipoVuelos, ArrayList<String> listaLicencias) {
		String licencias = "";
		String tipoVuelo = "";
		boolean valido = false;
		for (int i = 0; i < listaLicencias.size(); i++) {
			licencias = listaLicencias.get(i);
			for (int j = 0; j < tipoVuelos.size(); j++) {
				tipoVuelo = tipoVuelos.get(j);
				if (licencias == tipoVuelo) {
					System.out.println("El piloto puede pilotar el avión");
					valido = true;
				}
			}
		}
		return valido;
	}

}
