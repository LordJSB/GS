package poo03;

import java.util.ArrayList;

public class Vuelo {

	private ArrayList<PilotoAvion> pilotoVuelo = new ArrayList<>();
	private ArrayList<Avion> avionVuelo = new ArrayList<>();
	private String tarjetaEmbarque = "Ticket de Ejemplo";
	private String horaEmbarque = "Hora de Embarque de Ejemplo";
	private String horaSalida = "Hora de Salida de Ejemplo";
	private String horaLlegada = "Hora de Llegada de Ejemplo";
	private String aeropuertoSalida = "Aeropuerto de Salida de Ejemplo";
	private String aeropuertoEntrada = "Aeropuerto de Llegada de Ejemplo";

	public Vuelo(ArrayList<PilotoAvion> pilotoVuelo, ArrayList<Avion> avionVuelo, String tarjetaEmbarque,
			String horaEmbarque, String horaSalida, String horaLlegada, String aeropuertoSalida,
			String aeropuertoEntrada) {
		super();
		this.pilotoVuelo = pilotoVuelo;
		this.avionVuelo = avionVuelo;
		this.tarjetaEmbarque = tarjetaEmbarque;
		this.horaEmbarque = horaEmbarque;
		this.horaSalida = horaSalida;
		this.horaLlegada = horaLlegada;
		this.aeropuertoSalida = aeropuertoSalida;
		this.aeropuertoEntrada = aeropuertoEntrada;
	}

	public ArrayList<PilotoAvion> getPilotoVuelo() {return pilotoVuelo;}
	public void setPilotoVuelo(ArrayList<PilotoAvion> pilotoVuelo) {this.pilotoVuelo = pilotoVuelo;}

	public ArrayList<Avion> getAvionVuelo() {return avionVuelo;}
	public void setAvionVuelo(ArrayList<Avion> avionVuelo) {this.avionVuelo = avionVuelo;}

	public String getTarjetaEmbarque() {return tarjetaEmbarque;}
	public void setTarjetaEmbarque(String tarjetaEmbarque) {this.tarjetaEmbarque = tarjetaEmbarque;}

	public String getHoraEmbarque() {return horaEmbarque;}
	public void setHoraEmbarque(String horaEmbarque) {this.horaEmbarque = horaEmbarque;}

	public String getHoraSalida() {return horaSalida;}
	public void setHoraSalida(String horaSalida) {this.horaSalida = horaSalida;}

	public String getHoraLlegada() {return horaLlegada;}
	public void setHoraLlegada(String horaLlegada) {this.horaLlegada = horaLlegada;}
	
	public String getAeropuertoSalida() {return aeropuertoSalida;}
	public void setAeropuertoSalida(String aeropuertoSalida) {this.aeropuertoSalida = aeropuertoSalida;}
	
	public String getAeropuertoEntrada() {return aeropuertoEntrada;}
	public void setAeropuertoEntrada(String aeropuertoEntrada) {this.aeropuertoEntrada = aeropuertoEntrada;}

	public void balance(Avion a, ArrayList<Pasajero> pasajerosVuelo, PilotoAvion pa) {
		int balance = 0;
		int gasto = 0;
		int beneficio = 0;

		gasto = a.getGastoPorVuelo() + pa.getSalario();
		for (int i = 0; i < pasajerosVuelo.size(); i++) {
			beneficio = beneficio + pasajerosVuelo.get(i).getPrecioVuelo();
		}
		balance = beneficio - gasto;
		if (balance > 0) {
			System.out.println("El vuelo ha obtenido unos beneficios de " + balance + " euros");
		} else {
			System.out.println("El vuelo ha supuesto unas pérdidas de " + (-balance) + " euros");
		}
	}

	public void compruebaEmbarque(Vuelo v, Pasajero p) {		
		if(v.getTarjetaEmbarque() == p.getIdEmbarque()) {
			System.out.println("El pasajero puede viajar en el avión");
		}else {
			System.out.println("no amigo fumaste cabreiroas");
		}
	}
}
