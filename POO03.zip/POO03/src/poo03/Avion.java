package poo03;

import java.util.ArrayList;

public class Avion {

	private String modelo = "Modelo de Ejemplo";
	private String matricula = "Matrícula de avión de Ejemplo";
	private int numMotores = 0;
	private int capacidadPasajeros = 0;
	private ArrayList<String> tipoVuelos = new ArrayList<>();
	private int gastoPorVuelo = 0;
	
	public Avion(String modelo, String matricula, int numMotores, int capacidadPasajeros, ArrayList<String> tipoVuelos, int gastoPorVuelo) {
		super();
		this.modelo = modelo;
		this.matricula = matricula;
		this.numMotores = numMotores;
		this.capacidadPasajeros = capacidadPasajeros;
		this.tipoVuelos = tipoVuelos;
		this.gastoPorVuelo=gastoPorVuelo;
	}


	public String getModelo() {return modelo;}
	public void setModelo(String modelo) {this.modelo = modelo;}

	public String getMatricula() {return matricula;}
	public void setMatricula(String matricula) {this.matricula = matricula;}

	public int getNumMotores() {return numMotores;}
	public void setNumMotores(int numMotores) {this.numMotores = numMotores;}

	public int getCapacidadPasajeros() {return capacidadPasajeros;}
	public void setCapacidadPasajeros(int capacidadPasajeros) {this.capacidadPasajeros = capacidadPasajeros;}

	public ArrayList<String> getTipoVuelos() {return tipoVuelos;}
	public void setTipoVuelos(ArrayList<String> tipoVuelos) {this.tipoVuelos = tipoVuelos;}
		
	public int getGastoPorVuelo() {return gastoPorVuelo;}
	public void setGastoPorVuelo(int gastoPorVuelo) {this.gastoPorVuelo = gastoPorVuelo;}
}
