package poo03;

public class Pasajero {
	private String nombre = "Nombre de Ejemplo";
	private String apellidos = "Apellidos de Ejemplo";
	private String idEmbarque = "Identificador de Embarque de Ejemplo";
	private int precioVuelo = 0;
	
	public Pasajero(String nombre, String apellidos, String idEmbarque, int precioVuelo) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.idEmbarque = idEmbarque;
		this.precioVuelo = precioVuelo;
	}

	/*
	 * @return nombre del pasajero
	 *
	 */
	public String getNombre() {return nombre;}
	/*
	 * @return nombre del pasajero
	 *
	 */
	public void setNombre(String nombre) {this.nombre = nombre;}

	/*
	 * @return nombre del pasajero
	 *
	 */
	public String getApellidos() {return apellidos;}
	/*
	 * @return nombre del pasajero
	 *
	 */
	public void setApellidos(String apellidos) {this.apellidos = apellidos;}

	/*
	 * @return nombre del pasajero
	 *
	 */
	public String getIdEmbarque() {return idEmbarque;}
	/*
	 * @return nombre del pasajero
	 *
	 */
	public void setIdEmbarque(String idEmbarque) {this.idEmbarque = idEmbarque;}

	/*
	 * @return nombre del pasajero
	 *
	 */
	public int getPrecioVuelo() {return precioVuelo;}
	public void setPrecioVuelo(int precioVuelo) {this.precioVuelo = precioVuelo;}
	
	
}
