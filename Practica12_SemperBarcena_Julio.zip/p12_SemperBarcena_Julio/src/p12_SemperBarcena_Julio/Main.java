package p12_SemperBarcena_Julio;

/**

* Este programa lee un archivo .txt dado por el usuario, lee dicho archivo, y genera otro archivo .txt con la siguiente información:
* <ul>
* <li>Frecuencia de consonantes en un texto.</li>
* <li>Frecuencia de vocales en un texto y el porcentaje de aparición de cada vocal.</li>
* <li>Número total de líneas y de líneas vacías.</li>
* <li>Cantidad de números presentes en el texto.</li>
* <li>Una copia del texto contenido dentro del archivo invirtiendo las mayúsculas por minúsculas y viceversa.</li>
* </ul>
* Para usar este programa, el usuario debe insertar una dirección de archivo .txt.
* El programa devolverá otro archivo .txt con el siguiente patrón: "[nombreArchivoOriginal]_resultado.txt".
* @author Julio Semper
* @version 1.0
*/
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	/**
	 * Método principal. Lee la dirección de archivo dada por el usuario,convierte
	 * su contenido a una lista de Arrays y lo analiza. Genera un resultado que será
	 * impreso en un archivo .txt
	 *
	 * @param args parámetros dado por líneas de comando (No se usa).
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print(
				"Inserte la dirección del archivo de entrada.\nPuede obtener dicha dirección pulsando en a barra de direcciones del explorador de archivo de Windows: ");
		String entrada = sc.next();
		ArrayList<String> lista = new ArrayList<>();
		ArrayList<String> salida = new ArrayList<>();
		try (Scanner scanner = new Scanner(new File(entrada))) {
			while (scanner.hasNextLine()) {
				String linea = scanner.nextLine();
				String[] palabras = linea.split(" ");
				for (String pal : palabras) {
					lista.add(pal);
				}
			}
		} catch (FileNotFoundException e) {
			System.err.println("Archivo no encontrado: " + entrada);
			System.exit(1);
		}
		sc.close();
		cuentaConsonantes(lista, salida);
		cuentaVocalesXCiento(lista, salida);
		cuentaLineas(lista, salida);
		contadorNumeros(lista, salida);
		invierteMayus(lista, salida);
		escribeFichero(entrada, salida);
		System.out.println(
				"¡Hecho! El documento final se ha guardado en 'E:\\GS\\PRGRM\\Eclipse-Workspace\\p12_SemperBarcena_Julio'");
	}

	/**
	 * Este método lleva la cuenta de consonantes presentes en el texto
	 *
	 * @param entrada lista de Strings leída del texto
	 * @param salida  lista de Strings que indica la cantidad de consonantes totales
	 *                de la entrada
	 */
	private static void cuentaConsonantes(ArrayList<String> entrada, ArrayList<String> salida) {
		final String CONSONANTES = "bcdfghjklmnñpqrstvwxyz";
		int[] consonante = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		int pos = 0, total = 0;
		for (String lista : entrada) { // Recorremos la lista de elementos
			for (char letra : lista.toLowerCase().toCharArray()) { // Buscamos todos los caracteres
				for (char lector : CONSONANTES.toCharArray()) { // Buscamos su homónimo en nuestra lista de consonantes
					if (letra == lector) {
						consonante[(pos % 22)]++;
						total++;
					}
					pos++;
				}
			}
		}
		salida.add("Este texto contiene " + total + " consonantes\n");
		for (int i = 0; i < 22; i++) {
			if (consonante[i] != 0) {
				salida.add("La consonante " + CONSONANTES.toCharArray()[i] + " aparece " + consonante[i] + " veces\n");
			}
		}
	}

	/**
	 * Este método lleva la cuenta de vocales presentes en el texto. Se emplean las
	 * representaciones Unicode de A,E,I,O y U con tilde por incompatibilidades
	 * presentes en el Javadoc
	 *
	 * @param entrada lista de Strings leída del texto
	 * @param salida  lista de Strings que indica la cantidad de vocales totales de
	 *                la entrada
	 */
	private static void cuentaVocalesXCiento(ArrayList<String> entrada, ArrayList<String> salida) {
		final String VOCALES = "aeiouáéíóúAEIOUu\\00C1u\\00C9u\\00CDu\\00D3u\\00DA";
		DecimalFormat df = new DecimalFormat("####,##");
		int[] vocal = { 0, 0, 0, 0, 0 };
		int pos = 0;
		for (String lista : entrada) { // Recorremos la lista de elementos
			for (char letra : lista.toCharArray()) { // Buscamos todos los caracteres
				for (char lector : VOCALES.toCharArray()) { // Buscamos su homónimo en nuestra lista de vocales
					if (letra == lector) {
						vocal[(pos % 5)]++; // Aumentamos la posición adscrita a la vocal. Debido al órden de la lista
											// de vocales (de 5 en 5, se repiten las mismas vocales) nos permite
											// establecer la misma vocal pero con distintas características en la misma
											// posición en la lista final que guarda las vocales
					}
					pos++; // Una vez acabamos con una vocal, pasamos a la siguiente
				}
			}
		}
		int total = (vocal[0] + vocal[1] + vocal[2] + vocal[3] + vocal[4]);
		salida.add("Este texto contiene " + total + " vocales\n");
		for (int i = 0; i < 5; i++) {
			salida.add("La vocal " + VOCALES.toCharArray()[i] + " aparece " + vocal[i] + " veces\n");
		}
		for (int i = 0; i < 5; i++) {
			salida.add("La vocal " + VOCALES.toCharArray()[i] + " tiene un índice de aparición de "
					+ df.format(vocal[i] / total) + " veces\n");
		}
	}

	/**
	 * Este método lleva la cuenta de líneas presentes en el texto
	 *
	 * @param entrada lista de Strings leída del texto
	 * @param salida  lista de Strings que indica la cantidad de líneas totales y
	 *                líneas totales vacías de la entrada
	 */
	public static void cuentaLineas(ArrayList<String> entrada, ArrayList<String> salida) {
		int totalLineas = entrada.size();
		int contadorDeVacios = 0;
		for (String line : entrada) {
			if (line.trim().isEmpty()) {
				contadorDeVacios++;
			}
		}
		if (totalLineas == 1 && contadorDeVacios == 1) {
			salida.add("Cantidad de líneas totales: " + totalLineas + " línea\n");
			salida.add("Cantidad de líneas vacías: " + contadorDeVacios + " línea\n");
		} else if (totalLineas == 1 && contadorDeVacios != 1) {
			salida.add("Cantidad de líneas totales: " + totalLineas + " línea\n");
			salida.add("Cantidad de líneas vacías: " + contadorDeVacios + " líneas\n");
		} else if (totalLineas != 1 && contadorDeVacios == 1) {
			salida.add("Cantidad de líneas totales: " + totalLineas + " líneas\n");
			salida.add("Cantidad de líneas vacías: " + contadorDeVacios + " línea\n");
		} else {
			salida.add("Cantidad de líneas totales: " + totalLineas + " líneas\n");
			salida.add("Cantidad de líneas vacías: " + contadorDeVacios + " líneas\n");
		}

	}

	/**
	 * Este método invierte la capitalización de las letras del texto
	 *
	 * @param entrada lista de Strings leída del texto
	 * @param salida  lista de Strings con las mayúsculas y minúsculas del texto
	 *                invertido
	 */
	private static void invierteMayus(ArrayList<String> entrada, ArrayList<String> salida) {
		ArrayList<String> res = new ArrayList<>();
		for (String linea : entrada) {
			StringBuilder sb = new StringBuilder();
			for (char c : linea.toCharArray()) {
				if (Character.isUpperCase(c)) {
					sb.append(Character.toLowerCase(c));
				} else if (Character.isLowerCase(c)) {
					sb.append(Character.toUpperCase(c));
				} else {
					sb.append(c);
				}
			}
			res.add(sb.toString());
		}
		salida.add("El texto con las mayúsculas y minúsculas invertidas sería: " + res);
	}

	/**
	 * Este método cuenta el total de números del texto
	 *
	 * @param entrada lista de Strings leída del texto
	 * @param salida  lista de Strings con la cantidad total de números
	 */
	private static void contadorNumeros(ArrayList<String> entrada, ArrayList<String> salida) {
		final String NUMEROS = "0123456789";
		int contador = 0;
		for (char lector : NUMEROS.toCharArray()) {
			for (String lista : entrada) {
				for (char letra : lista.toCharArray()) {
					if (letra == lector) {
						contador++;
					}
				}
			}
		}
		if (contador != 1) {
			salida.add("De todos esos caracteres, hay " + contador + " números\n");
		} else {
			salida.add("De todos esos caracteres, hay " + contador + " número\n");
		}
	}

	/**
	 * Este método recoge todos los resultados obtenidos del resto de métodos, los
	 * establece en un fichero .txt y lo crea dentro del 'Workspace' actual
	 *
	 * @param entrada lista de Strings leída del texto
	 * @param salida  lista de Strings con el resultado completo final
	 */
	private static void escribeFichero(String entrada, ArrayList<String> salida) {
		entrada = entrada.replace(".txt", "_");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(entrada + "resultado.txt"));

			for (String l : salida) {
				bw.write(l + " ");
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}