package p12_SemperBarcena_Julio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * 
 * La clase {@code Archivo} representa un fichero legible por
 * {@link BufferedReader}, don un método que lee su contenido y lo guarda como
 * un String.
 * 
 * @author Julio Semper
 * @version 1.2
 */
public class Archivo {
	/**
	 * La dirección del archivo a leer.
	 */
	private String archivo;

	/**
	 * Constructor del objeto {@code Archivo} con su dirección de archivo.
	 * 
	 * @param archivo dirección de archivo a leer
	 */
	public Archivo(String archivo) {
		this.archivo = archivo;
	}

	/**
	 * lee el contenido del archivo y lo guarda como un String
	 * 
	 * @return el contenido del archivo
	 */
	public String leeArchivo() {
		StringBuilder sb = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while ((linea = br.readLine()) != null) {
				sb.append(linea).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
}